#ifndef __GENERATED_STATES_INCLUDE_GUARD__
#define __GENERATED_STATES_INCLUDE_GUARD__

#include "StateBase.hpp"
#include "DeepHistoryState.hpp"
#include "ShallowHistoryState.hpp"

// User Includes for the HFSM
//::::/c::::Includes::::
#include <stdio.h>

namespace StateMachine {

  // ROOT OF THE HFSM
  class Complex : public StateMachine::StateBase {
  public:

    // User Declarations for the HFSM
    //::::/c::::Declarations::::
      static bool goToEnd;
  static bool goToChoice;
  static bool goToHistory;
  static bool nextState;
  static bool killedState;
  static bool someGuard;
  static bool someTest;

  static int someNumber;
  static int someValue;

    // Child Substates
    /**
     * @brief Declaration for Complex::State_1 : /c/Y
     *
     * States contain other states and can consume generic
     * StateMachine::Event objects if they have internal or external
     * transitions on those events and if those transitions' guards are
     * satisfied. Only one transition can consume an event in a given
     * state machine.
     *
     * There is also a different kind of Event, the tick event, which is
     * not consumed, but instead executes from the top-level state all
     * the way to the curently active leaf state.
     *
     * Entry and Exit actions also occur whenever a state is entered or
     * exited, respectively.
     */
    class State_1 : public StateMachine::StateBase {
    public:
    
      
      // Timer period
      static const double timerPeriod;
    
      // Constructors
      State_1  ( void ) : StateBase( ) {}
      State_1  ( StateBase* _parent ) : StateBase( _parent ) {}
      ~State_1 ( void ) {}
    
      /**
       * @brief Calls entry() then handles any child
       *  initialization. Finally calls makeActive on the leaf.
       */
      void                     initialize ( void );
        
      /**
       * @brief Runs the entry() function defined in the model.
       */
      void                     entry ( void );
    
      /**
       * @brief Runs the exit() function defined in the model.
       */
      void                     exit ( void );
    
      /**
       * @brief Runs the tick() function defined in the model and then
       *  calls _activeState->tick().
       */
      void                     tick ( void );
    
      /**
       * @brief The timer period of the state in floating point seconds.
       *
       * @return  double  timer period
       */
      double                   getTimerPeriod ( void );
    
      /**
       * @brief Calls _activeState->handleEvent( event ), then if the
       *  event is not nullptr (meaning the event was not consumed by
       *  the child subtree), it checks the event against all internal
       *  transitions associated with that Event.  If the event is still
       *  not a nullptr (meaning the event was not consumed by the
       *  internal transitions), then it checks the event against all
       *  external transitions associated with that Event.
       *
       * @param[in] StateMachine::Event* Event needing to be handled
       *
       * @return true if event is consumed, false otherwise
       */
      bool                     handleEvent ( StateMachine::Event* event );
    };
    /**
     * @brief Declaration for Complex::State_2 : /c/v
     *
     * States contain other states and can consume generic
     * StateMachine::Event objects if they have internal or external
     * transitions on those events and if those transitions' guards are
     * satisfied. Only one transition can consume an event in a given
     * state machine.
     *
     * There is also a different kind of Event, the tick event, which is
     * not consumed, but instead executes from the top-level state all
     * the way to the curently active leaf state.
     *
     * Entry and Exit actions also occur whenever a state is entered or
     * exited, respectively.
     */
    class State_2 : public StateMachine::StateBase {
    public:
    
      /**
       * @brief Declaration for Complex::State_2::ChildState : /c/v/K
       *
       * States contain other states and can consume generic
       * StateMachine::Event objects if they have internal or external
       * transitions on those events and if those transitions' guards are
       * satisfied. Only one transition can consume an event in a given
       * state machine.
       *
       * There is also a different kind of Event, the tick event, which is
       * not consumed, but instead executes from the top-level state all
       * the way to the curently active leaf state.
       *
       * Entry and Exit actions also occur whenever a state is entered or
       * exited, respectively.
       */
      class ChildState : public StateMachine::StateBase {
      public:
      
        
        // Timer period
        static const double timerPeriod;
      
        // Constructors
        ChildState  ( void ) : StateBase( ) {}
        ChildState  ( StateBase* _parent ) : StateBase( _parent ) {}
        ~ChildState ( void ) {}
      
        /**
         * @brief Calls entry() then handles any child
         *  initialization. Finally calls makeActive on the leaf.
         */
        void                     initialize ( void );
          
        /**
         * @brief Runs the entry() function defined in the model.
         */
        void                     entry ( void );
      
        /**
         * @brief Runs the exit() function defined in the model.
         */
        void                     exit ( void );
      
        /**
         * @brief Runs the tick() function defined in the model and then
         *  calls _activeState->tick().
         */
        void                     tick ( void );
      
        /**
         * @brief The timer period of the state in floating point seconds.
         *
         * @return  double  timer period
         */
        double                   getTimerPeriod ( void );
      
        /**
         * @brief Calls _activeState->handleEvent( event ), then if the
         *  event is not nullptr (meaning the event was not consumed by
         *  the child subtree), it checks the event against all internal
         *  transitions associated with that Event.  If the event is still
         *  not a nullptr (meaning the event was not consumed by the
         *  internal transitions), then it checks the event against all
         *  external transitions associated with that Event.
         *
         * @param[in] StateMachine::Event* Event needing to be handled
         *
         * @return true if event is consumed, false otherwise
         */
        bool                     handleEvent ( StateMachine::Event* event );
      };
      /**
       * @brief Declaration for Complex::State_2::ChildState2 : /c/v/e
       *
       * States contain other states and can consume generic
       * StateMachine::Event objects if they have internal or external
       * transitions on those events and if those transitions' guards are
       * satisfied. Only one transition can consume an event in a given
       * state machine.
       *
       * There is also a different kind of Event, the tick event, which is
       * not consumed, but instead executes from the top-level state all
       * the way to the curently active leaf state.
       *
       * Entry and Exit actions also occur whenever a state is entered or
       * exited, respectively.
       */
      class ChildState2 : public StateMachine::StateBase {
      public:
      
        
        // Timer period
        static const double timerPeriod;
      
        // Constructors
        ChildState2  ( void ) : StateBase( ) {}
        ChildState2  ( StateBase* _parent ) : StateBase( _parent ) {}
        ~ChildState2 ( void ) {}
      
        /**
         * @brief Calls entry() then handles any child
         *  initialization. Finally calls makeActive on the leaf.
         */
        void                     initialize ( void );
          
        /**
         * @brief Runs the entry() function defined in the model.
         */
        void                     entry ( void );
      
        /**
         * @brief Runs the exit() function defined in the model.
         */
        void                     exit ( void );
      
        /**
         * @brief Runs the tick() function defined in the model and then
         *  calls _activeState->tick().
         */
        void                     tick ( void );
      
        /**
         * @brief The timer period of the state in floating point seconds.
         *
         * @return  double  timer period
         */
        double                   getTimerPeriod ( void );
      
        /**
         * @brief Calls _activeState->handleEvent( event ), then if the
         *  event is not nullptr (meaning the event was not consumed by
         *  the child subtree), it checks the event against all internal
         *  transitions associated with that Event.  If the event is still
         *  not a nullptr (meaning the event was not consumed by the
         *  internal transitions), then it checks the event against all
         *  external transitions associated with that Event.
         *
         * @param[in] StateMachine::Event* Event needing to be handled
         *
         * @return true if event is consumed, false otherwise
         */
        bool                     handleEvent ( StateMachine::Event* event );
      };
      /**
       * @brief Declaration for Complex::State_2::ChildState3 : /c/v/z
       *
       * States contain other states and can consume generic
       * StateMachine::Event objects if they have internal or external
       * transitions on those events and if those transitions' guards are
       * satisfied. Only one transition can consume an event in a given
       * state machine.
       *
       * There is also a different kind of Event, the tick event, which is
       * not consumed, but instead executes from the top-level state all
       * the way to the curently active leaf state.
       *
       * Entry and Exit actions also occur whenever a state is entered or
       * exited, respectively.
       */
      class ChildState3 : public StateMachine::StateBase {
      public:
      
        /**
         * @brief Declaration for Complex::State_2::ChildState3::Grand : /c/v/z/6
         *
         * States contain other states and can consume generic
         * StateMachine::Event objects if they have internal or external
         * transitions on those events and if those transitions' guards are
         * satisfied. Only one transition can consume an event in a given
         * state machine.
         *
         * There is also a different kind of Event, the tick event, which is
         * not consumed, but instead executes from the top-level state all
         * the way to the curently active leaf state.
         *
         * Entry and Exit actions also occur whenever a state is entered or
         * exited, respectively.
         */
        class Grand : public StateMachine::StateBase {
        public:
        
          
          // Timer period
          static const double timerPeriod;
        
          // Constructors
          Grand  ( void ) : StateBase( ) {}
          Grand  ( StateBase* _parent ) : StateBase( _parent ) {}
          ~Grand ( void ) {}
        
          /**
           * @brief Calls entry() then handles any child
           *  initialization. Finally calls makeActive on the leaf.
           */
          void                     initialize ( void );
            
          /**
           * @brief Runs the entry() function defined in the model.
           */
          void                     entry ( void );
        
          /**
           * @brief Runs the exit() function defined in the model.
           */
          void                     exit ( void );
        
          /**
           * @brief Runs the tick() function defined in the model and then
           *  calls _activeState->tick().
           */
          void                     tick ( void );
        
          /**
           * @brief The timer period of the state in floating point seconds.
           *
           * @return  double  timer period
           */
          double                   getTimerPeriod ( void );
        
          /**
           * @brief Calls _activeState->handleEvent( event ), then if the
           *  event is not nullptr (meaning the event was not consumed by
           *  the child subtree), it checks the event against all internal
           *  transitions associated with that Event.  If the event is still
           *  not a nullptr (meaning the event was not consumed by the
           *  internal transitions), then it checks the event against all
           *  external transitions associated with that Event.
           *
           * @param[in] StateMachine::Event* Event needing to be handled
           *
           * @return true if event is consumed, false otherwise
           */
          bool                     handleEvent ( StateMachine::Event* event );
        };
        /**
         * @brief Declaration for Complex::State_2::ChildState3::Grand2 : /c/v/z/c
         *
         * States contain other states and can consume generic
         * StateMachine::Event objects if they have internal or external
         * transitions on those events and if those transitions' guards are
         * satisfied. Only one transition can consume an event in a given
         * state machine.
         *
         * There is also a different kind of Event, the tick event, which is
         * not consumed, but instead executes from the top-level state all
         * the way to the curently active leaf state.
         *
         * Entry and Exit actions also occur whenever a state is entered or
         * exited, respectively.
         */
        class Grand2 : public StateMachine::StateBase {
        public:
        
          
          // Timer period
          static const double timerPeriod;
        
          // Constructors
          Grand2  ( void ) : StateBase( ) {}
          Grand2  ( StateBase* _parent ) : StateBase( _parent ) {}
          ~Grand2 ( void ) {}
        
          /**
           * @brief Calls entry() then handles any child
           *  initialization. Finally calls makeActive on the leaf.
           */
          void                     initialize ( void );
            
          /**
           * @brief Runs the entry() function defined in the model.
           */
          void                     entry ( void );
        
          /**
           * @brief Runs the exit() function defined in the model.
           */
          void                     exit ( void );
        
          /**
           * @brief Runs the tick() function defined in the model and then
           *  calls _activeState->tick().
           */
          void                     tick ( void );
        
          /**
           * @brief The timer period of the state in floating point seconds.
           *
           * @return  double  timer period
           */
          double                   getTimerPeriod ( void );
        
          /**
           * @brief Calls _activeState->handleEvent( event ), then if the
           *  event is not nullptr (meaning the event was not consumed by
           *  the child subtree), it checks the event against all internal
           *  transitions associated with that Event.  If the event is still
           *  not a nullptr (meaning the event was not consumed by the
           *  internal transitions), then it checks the event against all
           *  external transitions associated with that Event.
           *
           * @param[in] StateMachine::Event* Event needing to be handled
           *
           * @return true if event is consumed, false otherwise
           */
          bool                     handleEvent ( StateMachine::Event* event );
        };
        
        // Timer period
        static const double timerPeriod;
      
        // Constructors
        ChildState3  ( void ) : StateBase( ) {}
        ChildState3  ( StateBase* _parent ) : StateBase( _parent ) {}
        ~ChildState3 ( void ) {}
      
        /**
         * @brief Calls entry() then handles any child
         *  initialization. Finally calls makeActive on the leaf.
         */
        void                     initialize ( void );
          
        /**
         * @brief Runs the entry() function defined in the model.
         */
        void                     entry ( void );
      
        /**
         * @brief Runs the exit() function defined in the model.
         */
        void                     exit ( void );
      
        /**
         * @brief Runs the tick() function defined in the model and then
         *  calls _activeState->tick().
         */
        void                     tick ( void );
      
        /**
         * @brief The timer period of the state in floating point seconds.
         *
         * @return  double  timer period
         */
        double                   getTimerPeriod ( void );
      
        /**
         * @brief Calls _activeState->handleEvent( event ), then if the
         *  event is not nullptr (meaning the event was not consumed by
         *  the child subtree), it checks the event against all internal
         *  transitions associated with that Event.  If the event is still
         *  not a nullptr (meaning the event was not consumed by the
         *  internal transitions), then it checks the event against all
         *  external transitions associated with that Event.
         *
         * @param[in] StateMachine::Event* Event needing to be handled
         *
         * @return true if event is consumed, false otherwise
         */
        bool                     handleEvent ( StateMachine::Event* event );
      };
      
      // Timer period
      static const double timerPeriod;
    
      // Constructors
      State_2  ( void ) : StateBase( ) {}
      State_2  ( StateBase* _parent ) : StateBase( _parent ) {}
      ~State_2 ( void ) {}
    
      /**
       * @brief Calls entry() then handles any child
       *  initialization. Finally calls makeActive on the leaf.
       */
      void                     initialize ( void );
        
      /**
       * @brief Runs the entry() function defined in the model.
       */
      void                     entry ( void );
    
      /**
       * @brief Runs the exit() function defined in the model.
       */
      void                     exit ( void );
    
      /**
       * @brief Runs the tick() function defined in the model and then
       *  calls _activeState->tick().
       */
      void                     tick ( void );
    
      /**
       * @brief The timer period of the state in floating point seconds.
       *
       * @return  double  timer period
       */
      double                   getTimerPeriod ( void );
    
      /**
       * @brief Calls _activeState->handleEvent( event ), then if the
       *  event is not nullptr (meaning the event was not consumed by
       *  the child subtree), it checks the event against all internal
       *  transitions associated with that Event.  If the event is still
       *  not a nullptr (meaning the event was not consumed by the
       *  internal transitions), then it checks the event against all
       *  external transitions associated with that Event.
       *
       * @param[in] StateMachine::Event* Event needing to be handled
       *
       * @return true if event is consumed, false otherwise
       */
      bool                     handleEvent ( StateMachine::Event* event );
    };
    /**
     * @brief Declaration for Complex::State3 : /c/T
     *
     * States contain other states and can consume generic
     * StateMachine::Event objects if they have internal or external
     * transitions on those events and if those transitions' guards are
     * satisfied. Only one transition can consume an event in a given
     * state machine.
     *
     * There is also a different kind of Event, the tick event, which is
     * not consumed, but instead executes from the top-level state all
     * the way to the curently active leaf state.
     *
     * Entry and Exit actions also occur whenever a state is entered or
     * exited, respectively.
     */
    class State3 : public StateMachine::StateBase {
    public:
    
      /**
       * @brief Declaration for Complex::State3::ChildState2 : /c/T/0
       *
       * States contain other states and can consume generic
       * StateMachine::Event objects if they have internal or external
       * transitions on those events and if those transitions' guards are
       * satisfied. Only one transition can consume an event in a given
       * state machine.
       *
       * There is also a different kind of Event, the tick event, which is
       * not consumed, but instead executes from the top-level state all
       * the way to the curently active leaf state.
       *
       * Entry and Exit actions also occur whenever a state is entered or
       * exited, respectively.
       */
      class ChildState2 : public StateMachine::StateBase {
      public:
      
        
        // Timer period
        static const double timerPeriod;
      
        // Constructors
        ChildState2  ( void ) : StateBase( ) {}
        ChildState2  ( StateBase* _parent ) : StateBase( _parent ) {}
        ~ChildState2 ( void ) {}
      
        /**
         * @brief Calls entry() then handles any child
         *  initialization. Finally calls makeActive on the leaf.
         */
        void                     initialize ( void );
          
        /**
         * @brief Runs the entry() function defined in the model.
         */
        void                     entry ( void );
      
        /**
         * @brief Runs the exit() function defined in the model.
         */
        void                     exit ( void );
      
        /**
         * @brief Runs the tick() function defined in the model and then
         *  calls _activeState->tick().
         */
        void                     tick ( void );
      
        /**
         * @brief The timer period of the state in floating point seconds.
         *
         * @return  double  timer period
         */
        double                   getTimerPeriod ( void );
      
        /**
         * @brief Calls _activeState->handleEvent( event ), then if the
         *  event is not nullptr (meaning the event was not consumed by
         *  the child subtree), it checks the event against all internal
         *  transitions associated with that Event.  If the event is still
         *  not a nullptr (meaning the event was not consumed by the
         *  internal transitions), then it checks the event against all
         *  external transitions associated with that Event.
         *
         * @param[in] StateMachine::Event* Event needing to be handled
         *
         * @return true if event is consumed, false otherwise
         */
        bool                     handleEvent ( StateMachine::Event* event );
      };
      /**
       * @brief Declaration for Complex::State3::ChildState : /c/T/W
       *
       * States contain other states and can consume generic
       * StateMachine::Event objects if they have internal or external
       * transitions on those events and if those transitions' guards are
       * satisfied. Only one transition can consume an event in a given
       * state machine.
       *
       * There is also a different kind of Event, the tick event, which is
       * not consumed, but instead executes from the top-level state all
       * the way to the curently active leaf state.
       *
       * Entry and Exit actions also occur whenever a state is entered or
       * exited, respectively.
       */
      class ChildState : public StateMachine::StateBase {
      public:
      
        
        // Timer period
        static const double timerPeriod;
      
        // Constructors
        ChildState  ( void ) : StateBase( ) {}
        ChildState  ( StateBase* _parent ) : StateBase( _parent ) {}
        ~ChildState ( void ) {}
      
        /**
         * @brief Calls entry() then handles any child
         *  initialization. Finally calls makeActive on the leaf.
         */
        void                     initialize ( void );
          
        /**
         * @brief Runs the entry() function defined in the model.
         */
        void                     entry ( void );
      
        /**
         * @brief Runs the exit() function defined in the model.
         */
        void                     exit ( void );
      
        /**
         * @brief Runs the tick() function defined in the model and then
         *  calls _activeState->tick().
         */
        void                     tick ( void );
      
        /**
         * @brief The timer period of the state in floating point seconds.
         *
         * @return  double  timer period
         */
        double                   getTimerPeriod ( void );
      
        /**
         * @brief Calls _activeState->handleEvent( event ), then if the
         *  event is not nullptr (meaning the event was not consumed by
         *  the child subtree), it checks the event against all internal
         *  transitions associated with that Event.  If the event is still
         *  not a nullptr (meaning the event was not consumed by the
         *  internal transitions), then it checks the event against all
         *  external transitions associated with that Event.
         *
         * @param[in] StateMachine::Event* Event needing to be handled
         *
         * @return true if event is consumed, false otherwise
         */
        bool                     handleEvent ( StateMachine::Event* event );
      };
      /**
       * @brief Declaration for Complex::State3::ChildState3 : /c/T/w
       *
       * States contain other states and can consume generic
       * StateMachine::Event objects if they have internal or external
       * transitions on those events and if those transitions' guards are
       * satisfied. Only one transition can consume an event in a given
       * state machine.
       *
       * There is also a different kind of Event, the tick event, which is
       * not consumed, but instead executes from the top-level state all
       * the way to the curently active leaf state.
       *
       * Entry and Exit actions also occur whenever a state is entered or
       * exited, respectively.
       */
      class ChildState3 : public StateMachine::StateBase {
      public:
      
        
        // Timer period
        static const double timerPeriod;
      
        // Constructors
        ChildState3  ( void ) : StateBase( ) {}
        ChildState3  ( StateBase* _parent ) : StateBase( _parent ) {}
        ~ChildState3 ( void ) {}
      
        /**
         * @brief Calls entry() then handles any child
         *  initialization. Finally calls makeActive on the leaf.
         */
        void                     initialize ( void );
          
        /**
         * @brief Runs the entry() function defined in the model.
         */
        void                     entry ( void );
      
        /**
         * @brief Runs the exit() function defined in the model.
         */
        void                     exit ( void );
      
        /**
         * @brief Runs the tick() function defined in the model and then
         *  calls _activeState->tick().
         */
        void                     tick ( void );
      
        /**
         * @brief The timer period of the state in floating point seconds.
         *
         * @return  double  timer period
         */
        double                   getTimerPeriod ( void );
      
        /**
         * @brief Calls _activeState->handleEvent( event ), then if the
         *  event is not nullptr (meaning the event was not consumed by
         *  the child subtree), it checks the event against all internal
         *  transitions associated with that Event.  If the event is still
         *  not a nullptr (meaning the event was not consumed by the
         *  internal transitions), then it checks the event against all
         *  external transitions associated with that Event.
         *
         * @param[in] StateMachine::Event* Event needing to be handled
         *
         * @return true if event is consumed, false otherwise
         */
        bool                     handleEvent ( StateMachine::Event* event );
      };
      
      // Timer period
      static const double timerPeriod;
    
      // Constructors
      State3  ( void ) : StateBase( ) {}
      State3  ( StateBase* _parent ) : StateBase( _parent ) {}
      ~State3 ( void ) {}
    
      /**
       * @brief Calls entry() then handles any child
       *  initialization. Finally calls makeActive on the leaf.
       */
      void                     initialize ( void );
        
      /**
       * @brief Runs the entry() function defined in the model.
       */
      void                     entry ( void );
    
      /**
       * @brief Runs the exit() function defined in the model.
       */
      void                     exit ( void );
    
      /**
       * @brief Runs the tick() function defined in the model and then
       *  calls _activeState->tick().
       */
      void                     tick ( void );
    
      /**
       * @brief The timer period of the state in floating point seconds.
       *
       * @return  double  timer period
       */
      double                   getTimerPeriod ( void );
    
      /**
       * @brief Calls _activeState->handleEvent( event ), then if the
       *  event is not nullptr (meaning the event was not consumed by
       *  the child subtree), it checks the event against all internal
       *  transitions associated with that Event.  If the event is still
       *  not a nullptr (meaning the event was not consumed by the
       *  internal transitions), then it checks the event against all
       *  external transitions associated with that Event.
       *
       * @param[in] StateMachine::Event* Event needing to be handled
       *
       * @return true if event is consumed, false otherwise
       */
      bool                     handleEvent ( StateMachine::Event* event );
    };
    // END STATE
    /**
     * @brief This is the terminal END STATE for the HFSM, after which no
     *  events or other actions will be processed.
     */
    class End_State : public StateMachine::StateBase {
    public:
      
      /**
       * @brief Empty function for the END STATE.
       */
      void entry ( void ) {}
    
      /**
       * @brief Empty function for the END STATE.
       */
      void exit ( void ) {}
    
      /**
       * @brief Empty function for the END STATE.
       */
      void tick ( void ) {}
    
      /**
       * @brief Empty function for the END STATE. Simply returns true
       *  since the END STATE trivially handles all events.
       *
       * @return true 
       */
      bool handleEvent ( StateMachine::Event* event ) { return true; }
    };

    // Constructors
    Complex  ( void ) : StateBase( ) {}
    Complex  ( StateBase* _parent ) : StateBase( _parent ) {}
    ~Complex ( void ) {}
    
    /**
     * @brief Fully initializes the HFSM. Runs the HFSM Initialization
     *  code from the model, then sets the inital state and runs the
     *  initial transition and entry actions accordingly.
     */
    void                     initialize ( void );
    
    /**
     * @brief Terminates the HFSM, calling exit functions for the
     *  active leaf state upwards through its parents all the way to
     *  the root.
     */
    void                     terminate  ( void );

    /**
     * @brief Restarts the HFSM by calling terminate and then
     *  initialize.
     */
    void                     restart    ( void );

    /**
     * @brief Returns true if the HFSM has reached its END State
     */
    bool                     hasStopped ( void );

    /**
     * @brief Calls handleEvent on the activeLeaf.
     *
     * @param[in] StateMachine::Event* Event needing to be handled
     *
     * @return true if event is consumed, false otherwise
     */
    bool                     handleEvent ( StateMachine::Event* event );
  };
};

// pointers
extern StateMachine::Complex *const Complex_root;
extern StateMachine::Complex *const COMPLEX_OBJ;
extern StateMachine::Complex::State_1 *const COMPLEX_OBJ__STATE_1_OBJ;
extern StateMachine::Complex::State_2 *const COMPLEX_OBJ__STATE_2_OBJ;
extern StateMachine::Complex::State_2::ChildState *const COMPLEX_OBJ__STATE_2_OBJ__CHILDSTATE_OBJ;
extern StateMachine::DeepHistoryState *const COMPLEX_OBJ__STATE_2_OBJ__DEEP_HISTORY_PSEUDOSTATE_OBJ;
extern StateMachine::Complex::State_2::ChildState2 *const COMPLEX_OBJ__STATE_2_OBJ__CHILDSTATE2_OBJ;
extern StateMachine::Complex::State_2::ChildState3 *const COMPLEX_OBJ__STATE_2_OBJ__CHILDSTATE3_OBJ;
extern StateMachine::Complex::State_2::ChildState3::Grand *const COMPLEX_OBJ__STATE_2_OBJ__CHILDSTATE3_OBJ__GRAND_OBJ;
extern StateMachine::Complex::State_2::ChildState3::Grand2 *const COMPLEX_OBJ__STATE_2_OBJ__CHILDSTATE3_OBJ__GRAND2_OBJ;
extern StateMachine::ShallowHistoryState *const COMPLEX_OBJ__STATE_2_OBJ__SHALLOW_HISTORY_PSEUDOSTATE_OBJ;
extern StateMachine::Complex::State3 *const COMPLEX_OBJ__STATE3_OBJ;
extern StateMachine::Complex::State3::ChildState2 *const COMPLEX_OBJ__STATE3_OBJ__CHILDSTATE2_OBJ;
extern StateMachine::ShallowHistoryState *const COMPLEX_OBJ__STATE3_OBJ__SHALLOW_HISTORY_PSEUDOSTATE_OBJ;
extern StateMachine::DeepHistoryState *const COMPLEX_OBJ__STATE3_OBJ__DEEP_HISTORY_PSEUDOSTATE_OBJ;
extern StateMachine::Complex::State3::ChildState *const COMPLEX_OBJ__STATE3_OBJ__CHILDSTATE_OBJ;
extern StateMachine::Complex::State3::ChildState3 *const COMPLEX_OBJ__STATE3_OBJ__CHILDSTATE3_OBJ;
extern StateMachine::StateBase *const COMPLEX_OBJ__END_STATE_OBJ;
#endif // __GENERATED_STATES_INCLUDE_GUARD__
