#include "Complex_Events.hpp"
#include "Complex_GeneratedStates.hpp"

#ifdef DEBUG_OUTPUT
#include <iostream>
#endif

namespace StateMachine {
  StateMachine::Complex        COMPLEX_OBJ_stateObj;
  StateMachine::Complex *const COMPLEX_OBJ = &COMPLEX_OBJ_stateObj;
  StateMachine::Complex::State_1        COMPLEX_OBJ__STATE_1_OBJ_stateObj( COMPLEX_OBJ );
  StateMachine::Complex::State_1 *const COMPLEX_OBJ__STATE_1_OBJ = &COMPLEX_OBJ__STATE_1_OBJ_stateObj;
  
  StateMachine::Complex::State_2        COMPLEX_OBJ__STATE_2_OBJ_stateObj( COMPLEX_OBJ );
  StateMachine::Complex::State_2 *const COMPLEX_OBJ__STATE_2_OBJ = &COMPLEX_OBJ__STATE_2_OBJ_stateObj;
  
  StateMachine::Complex::State_2::ChildState        COMPLEX_OBJ__STATE_2_OBJ__CHILDSTATE_OBJ_stateObj( COMPLEX_OBJ__STATE_2_OBJ );
  StateMachine::Complex::State_2::ChildState *const COMPLEX_OBJ__STATE_2_OBJ__CHILDSTATE_OBJ = &COMPLEX_OBJ__STATE_2_OBJ__CHILDSTATE_OBJ_stateObj;
  
  StateMachine::DeepHistoryState           COMPLEX_OBJ__STATE_2_OBJ__DEEP_HISTORY_PSEUDOSTATE_OBJ_stateObj( COMPLEX_OBJ__STATE_2_OBJ );
  StateMachine::DeepHistoryState    *const COMPLEX_OBJ__STATE_2_OBJ__DEEP_HISTORY_PSEUDOSTATE_OBJ = &COMPLEX_OBJ__STATE_2_OBJ__DEEP_HISTORY_PSEUDOSTATE_OBJ_stateObj;
  
  StateMachine::Complex::State_2::ChildState2        COMPLEX_OBJ__STATE_2_OBJ__CHILDSTATE2_OBJ_stateObj( COMPLEX_OBJ__STATE_2_OBJ );
  StateMachine::Complex::State_2::ChildState2 *const COMPLEX_OBJ__STATE_2_OBJ__CHILDSTATE2_OBJ = &COMPLEX_OBJ__STATE_2_OBJ__CHILDSTATE2_OBJ_stateObj;
  
  StateMachine::Complex::State_2::ChildState3        COMPLEX_OBJ__STATE_2_OBJ__CHILDSTATE3_OBJ_stateObj( COMPLEX_OBJ__STATE_2_OBJ );
  StateMachine::Complex::State_2::ChildState3 *const COMPLEX_OBJ__STATE_2_OBJ__CHILDSTATE3_OBJ = &COMPLEX_OBJ__STATE_2_OBJ__CHILDSTATE3_OBJ_stateObj;
  StateMachine::Complex::State_2::ChildState3::Grand        COMPLEX_OBJ__STATE_2_OBJ__CHILDSTATE3_OBJ__GRAND_OBJ_stateObj( COMPLEX_OBJ__STATE_2_OBJ__CHILDSTATE3_OBJ );
  StateMachine::Complex::State_2::ChildState3::Grand *const COMPLEX_OBJ__STATE_2_OBJ__CHILDSTATE3_OBJ__GRAND_OBJ = &COMPLEX_OBJ__STATE_2_OBJ__CHILDSTATE3_OBJ__GRAND_OBJ_stateObj;
  
  
  StateMachine::Complex::State_2::ChildState3::Grand2        COMPLEX_OBJ__STATE_2_OBJ__CHILDSTATE3_OBJ__GRAND2_OBJ_stateObj( COMPLEX_OBJ__STATE_2_OBJ__CHILDSTATE3_OBJ );
  StateMachine::Complex::State_2::ChildState3::Grand2 *const COMPLEX_OBJ__STATE_2_OBJ__CHILDSTATE3_OBJ__GRAND2_OBJ = &COMPLEX_OBJ__STATE_2_OBJ__CHILDSTATE3_OBJ__GRAND2_OBJ_stateObj;
  
  
  StateMachine::ShallowHistoryState        COMPLEX_OBJ__STATE_2_OBJ__SHALLOW_HISTORY_PSEUDOSTATE_OBJ_stateObj( COMPLEX_OBJ__STATE_2_OBJ );
  StateMachine::ShallowHistoryState *const COMPLEX_OBJ__STATE_2_OBJ__SHALLOW_HISTORY_PSEUDOSTATE_OBJ = &COMPLEX_OBJ__STATE_2_OBJ__SHALLOW_HISTORY_PSEUDOSTATE_OBJ_stateObj;
  
  
  StateMachine::Complex::State3        COMPLEX_OBJ__STATE3_OBJ_stateObj( COMPLEX_OBJ );
  StateMachine::Complex::State3 *const COMPLEX_OBJ__STATE3_OBJ = &COMPLEX_OBJ__STATE3_OBJ_stateObj;
  StateMachine::Complex::State3::ChildState2        COMPLEX_OBJ__STATE3_OBJ__CHILDSTATE2_OBJ_stateObj( COMPLEX_OBJ__STATE3_OBJ );
  StateMachine::Complex::State3::ChildState2 *const COMPLEX_OBJ__STATE3_OBJ__CHILDSTATE2_OBJ = &COMPLEX_OBJ__STATE3_OBJ__CHILDSTATE2_OBJ_stateObj;
  
  StateMachine::ShallowHistoryState        COMPLEX_OBJ__STATE3_OBJ__SHALLOW_HISTORY_PSEUDOSTATE_OBJ_stateObj( COMPLEX_OBJ__STATE3_OBJ );
  StateMachine::ShallowHistoryState *const COMPLEX_OBJ__STATE3_OBJ__SHALLOW_HISTORY_PSEUDOSTATE_OBJ = &COMPLEX_OBJ__STATE3_OBJ__SHALLOW_HISTORY_PSEUDOSTATE_OBJ_stateObj;
  
  StateMachine::DeepHistoryState           COMPLEX_OBJ__STATE3_OBJ__DEEP_HISTORY_PSEUDOSTATE_OBJ_stateObj( COMPLEX_OBJ__STATE3_OBJ );
  StateMachine::DeepHistoryState    *const COMPLEX_OBJ__STATE3_OBJ__DEEP_HISTORY_PSEUDOSTATE_OBJ = &COMPLEX_OBJ__STATE3_OBJ__DEEP_HISTORY_PSEUDOSTATE_OBJ_stateObj;
  
  StateMachine::Complex::State3::ChildState        COMPLEX_OBJ__STATE3_OBJ__CHILDSTATE_OBJ_stateObj( COMPLEX_OBJ__STATE3_OBJ );
  StateMachine::Complex::State3::ChildState *const COMPLEX_OBJ__STATE3_OBJ__CHILDSTATE_OBJ = &COMPLEX_OBJ__STATE3_OBJ__CHILDSTATE_OBJ_stateObj;
  
  StateMachine::Complex::State3::ChildState3        COMPLEX_OBJ__STATE3_OBJ__CHILDSTATE3_OBJ_stateObj( COMPLEX_OBJ__STATE3_OBJ );
  StateMachine::Complex::State3::ChildState3 *const COMPLEX_OBJ__STATE3_OBJ__CHILDSTATE3_OBJ = &COMPLEX_OBJ__STATE3_OBJ__CHILDSTATE3_OBJ_stateObj;
  
  
  
  
  StateMachine::StateBase         COMPLEX_OBJ__END_STATE_OBJ_stateObj( COMPLEX_OBJ );
  StateMachine::StateBase *const  COMPLEX_OBJ__END_STATE_OBJ = &COMPLEX_OBJ__END_STATE_OBJ_stateObj;
  // User Definitions for the HFSM
  //::::/c::::Definitions::::
    bool Complex::goToEnd      = false;
  bool Complex::goToChoice   = true;
  bool Complex::goToHistory  = false;
  bool Complex::nextState    = false;
  bool Complex::killedState  = false;
  bool Complex::someGuard    = true;
  bool Complex::someTest     = true;

  int Complex::someNumber = 40;
  int Complex::someValue  = 50;

  /* * *  Definitions for Complex : /c  * * */
  // Generated Definitions for the root state
  void Complex::initialize ( void ) {
    // Run the model's Initialization code
    #ifdef DEBUG_OUTPUT
    std::cout << "Complex:/c HFSM Initialization" << std::endl;
    #endif
    //::::/c::::Initialization::::
    
    // now set the states up properly
    // External Transition : Action for: /c/m
    #ifdef DEBUG_OUTPUT
    std::cout << "TRANSITION::ACTION for /c/m" << std::endl;
    #endif
    
    //::::/c/m::::Action::::
    
    // State : entry for: /c/Y
    COMPLEX_OBJ__STATE_1_OBJ->entry();
    
    // initialize our new active state
    COMPLEX_OBJ__STATE_1_OBJ->initialize();
  };
  
  void Complex::terminate ( void ) {
    // will call exit() and exitChildren() on _activeState if it
    // exists
    exitChildren();
  };
  
  void Complex::restart ( void ) {
    terminate();
    initialize();
  };
  
  bool Complex::hasStopped ( void ) {
    bool reachedEnd = false;
    // Get the currently active leaf state
    StateMachine::StateBase* activeLeaf = getActiveLeaf();
    if (activeLeaf != nullptr && activeLeaf != this && activeLeaf == COMPLEX_OBJ__END_STATE_OBJ) {
      reachedEnd = true;
    }
    return reachedEnd;
  };
  
  bool Complex::handleEvent ( StateMachine::Event* event ) {
    bool handled = false;

    // Get the currently active leaf state
    StateMachine::StateBase* activeLeaf = getActiveLeaf();

    if (activeLeaf != nullptr && activeLeaf != this) {
      // have the active leaf handle the event, this will bubble up until
      // the event is handled or it reaches the root.
      handled = activeLeaf->handleEvent( event );
    }

    return handled;
  }
  /* * *  Definitions for Complex::State_1 : /c/Y  * * */
  // Timer period
  const double Complex::State_1::timerPeriod = 0.1;
  
  void Complex::State_1::initialize ( void ) {
    // if we're a leaf state, make sure we're active
    makeActive();
  }
  
  void Complex::State_1::entry ( void ) {
    #ifdef DEBUG_OUTPUT
    std::cout << "ENTRY::Complex::State_1::/c/Y" << std::endl;
    #endif
    // Entry action for this state
    //::::/c/Y::::Entry::::
    int a = 2;
  printf("SerialTask :: initializing State 1\n");
  }
  
  void Complex::State_1::exit ( void ) {
    #ifdef DEBUG_OUTPUT
    std::cout << "EXIT::Complex::State_1::/c/Y" << std::endl;
    #endif
    // Call the Exit Action for this state
    //::::/c/Y::::Exit::::
        printf("Exiting State 1\n");
  }
  
  void Complex::State_1::tick ( void ) {
    #ifdef DEBUG_OUTPUT
    std::cout << "TICK::Complex::State_1::/c/Y" << std::endl;
    #endif
    // Call the Tick Action for this state
    //::::/c/Y::::Tick::::
          printf("SerialTask::State 1::tick()\n");
    if ( _activeState != nullptr && _activeState != this )
      _activeState->tick();
  }
  
  double Complex::State_1::getTimerPeriod ( void ) {
    return timerPeriod;
  }
  
  bool Complex::State_1::handleEvent ( StateMachine::Event* event ) {
    bool handled = false;
  
    // take care of all event types that this branch will not handle -
    // for more consistent run-time performnace
    switch ( event->type() ) {
    case Event::Type::ENDEVENT:
      handled = true;
      break;
    case Event::Type::EVENT3:
      handled = true;
      break;
    default:
      break;
    }
  
    if (handled) {
      // we didn't actually handle the event, but return anyway
      return false;
    }
  
    // handle internal transitions first
    switch ( event->type() ) {
    case Event::Type::EVENT1:
      if ( false ) {  // makes generation easier :)
      }
      //::::/c/Y/t::::Guard::::
      else if ( someNumber < someValue ) {
        #ifdef DEBUG_OUTPUT
        std::cout << "GUARD [ someNumber < someValue ] for INTERNAL TRANSITION:/c/Y/t evaluated to TRUE" << std::endl;
        #endif
        // run transition action
        //::::/c/Y/t::::Action::::
        int testVal = 32;
    for (int i=0; i<testVal; i++) {
        printf("Action iterating: %d\n", i);
    }
        // make sure nothing else handles this event
        handled = true;
      }
      break;
    case Event::Type::EVENT2:
      if ( false ) {  // makes generation easier :)
      }
      //::::/c/Y/X::::Guard::::
      else if ( someNumber > someValue ) {
        #ifdef DEBUG_OUTPUT
        std::cout << "GUARD [ someNumber > someValue ] for INTERNAL TRANSITION:/c/Y/X evaluated to TRUE" << std::endl;
        #endif
        // run transition action
        //::::/c/Y/X::::Action::::
        
        // make sure nothing else handles this event
        handled = true;
      }
      break;
    default:
      break;
    }
    if (!handled) {
      // handle external transitions here
      switch ( event->type() ) {
      case Event::Type::EVENT4:
        if ( false ) { }  // makes generation easier :)
        //::::/c/I::::Guard::::
        else if ( someTest ) {
          #ifdef DEBUG_OUTPUT
          std::cout << "GUARD [ someTest ] for EXTERNAL TRANSITION:/c/I evaluated to TRUE" << std::endl;
          #endif
          // Going into a choice pseudo-state, let it handle its
          // guards and perform the state transition
          if (false) { } // makes geneeration easier :)
          //::::/c/h::::Guard::::
          else if ( goToHistory ) {
            #ifdef DEBUG_OUTPUT
            std::cout << "GUARD [ goToHistory ] for EXTERNAL TRANSITION:/c/h evaluated to TRUE" << std::endl;
            #endif
            // Transitioning states!
            // Call all from prev state down exits
          COMPLEX_OBJ__STATE_1_OBJ->exitChildren();
          // State : exit for: /c/Y
          COMPLEX_OBJ__STATE_1_OBJ->exit();
          // External Transition : Action for: /c/I
          #ifdef DEBUG_OUTPUT
          std::cout << "TRANSITION::ACTION for /c/I" << std::endl;
          #endif
          
          //::::/c/I::::Action::::
          
          // External Transition : Action for: /c/h
          #ifdef DEBUG_OUTPUT
          std::cout << "TRANSITION::ACTION for /c/h" << std::endl;
          #endif
          
          //::::/c/h::::Action::::
          
          // State : entry for: /c/T
          COMPLEX_OBJ__STATE3_OBJ->entry();
          #ifdef DEBUG_OUTPUT
          std::cout << "STATE TRANSITION: Complex::State_1->Complex::State3::Shallow_History_Pseudostate" << std::endl;
          #endif
          
            // going into shallow history pseudo-state
            COMPLEX_OBJ__STATE3_OBJ->setShallowHistory();
              // make sure nothing else handles this event
            handled = true;
            }
          //::::/c/k::::Guard::::
          else if ( nextState ) {
            #ifdef DEBUG_OUTPUT
            std::cout << "GUARD [ nextState ] for EXTERNAL TRANSITION:/c/k evaluated to TRUE" << std::endl;
            #endif
            // Transitioning states!
            // Call all from prev state down exits
          COMPLEX_OBJ__STATE_1_OBJ->exitChildren();
          // State : exit for: /c/Y
          COMPLEX_OBJ__STATE_1_OBJ->exit();
          // External Transition : Action for: /c/I
          #ifdef DEBUG_OUTPUT
          std::cout << "TRANSITION::ACTION for /c/I" << std::endl;
          #endif
          
          //::::/c/I::::Action::::
          
          // External Transition : Action for: /c/k
          #ifdef DEBUG_OUTPUT
          std::cout << "TRANSITION::ACTION for /c/k" << std::endl;
          #endif
          
          //::::/c/k::::Action::::
          
          // State : entry for: /c/v
          COMPLEX_OBJ__STATE_2_OBJ->entry();
          #ifdef DEBUG_OUTPUT
          std::cout << "STATE TRANSITION: Complex::State_1->Complex::State_2" << std::endl;
          #endif
          
            // going into regular state
            COMPLEX_OBJ__STATE_2_OBJ->initialize();
            // make sure nothing else handles this event
            handled = true;
            }
          else if ( true ) {
            #ifdef DEBUG_OUTPUT
            std::cout << "NO GUARD on EXTERNAL TRANSITION:/c/o" << std::endl;
            #endif
            // Transitioning states!
            // Call all from prev state down exits
          COMPLEX_OBJ__STATE_1_OBJ->exitChildren();
          // State : exit for: /c/Y
          COMPLEX_OBJ__STATE_1_OBJ->exit();
          // External Transition : Action for: /c/I
          #ifdef DEBUG_OUTPUT
          std::cout << "TRANSITION::ACTION for /c/I" << std::endl;
          #endif
          
          //::::/c/I::::Action::::
          
          // External Transition : Action for: /c/o
          #ifdef DEBUG_OUTPUT
          std::cout << "TRANSITION::ACTION for /c/o" << std::endl;
          #endif
          
          //::::/c/o::::Action::::
          
          // State : entry for: /c/T
          COMPLEX_OBJ__STATE3_OBJ->entry();
          #ifdef DEBUG_OUTPUT
          std::cout << "STATE TRANSITION: Complex::State_1->Complex::State3" << std::endl;
          #endif
          
            // going into regular state
            COMPLEX_OBJ__STATE3_OBJ->initialize();
            // make sure nothing else handles this event
            handled = true;
            }
        }
        break;
      default:
        break;
      }
    }
    // can't buble up, we are a root state.
    return handled;
  }
  /* * *  Definitions for Complex::State_2 : /c/v  * * */
  // Timer period
  const double Complex::State_2::timerPeriod = 0;
  
  void Complex::State_2::initialize ( void ) {
    // External Transition : Action for: /c/v/u
    #ifdef DEBUG_OUTPUT
    std::cout << "TRANSITION::ACTION for /c/v/u" << std::endl;
    #endif
    
    //::::/c/v/u::::Action::::
    
    // State : entry for: /c/v/K
    COMPLEX_OBJ__STATE_2_OBJ__CHILDSTATE_OBJ->entry();
    
    // initialize our new active state
    COMPLEX_OBJ__STATE_2_OBJ__CHILDSTATE_OBJ->initialize();
  }
  
  void Complex::State_2::entry ( void ) {
    #ifdef DEBUG_OUTPUT
    std::cout << "ENTRY::Complex::State_2::/c/v" << std::endl;
    #endif
    // Entry action for this state
    //::::/c/v::::Entry::::
    
  }
  
  void Complex::State_2::exit ( void ) {
    #ifdef DEBUG_OUTPUT
    std::cout << "EXIT::Complex::State_2::/c/v" << std::endl;
    #endif
    // Call the Exit Action for this state
    //::::/c/v::::Exit::::
    
  }
  
  void Complex::State_2::tick ( void ) {
    #ifdef DEBUG_OUTPUT
    std::cout << "TICK::Complex::State_2::/c/v" << std::endl;
    #endif
    // Call the Tick Action for this state
    //::::/c/v::::Tick::::
    
    if ( _activeState != nullptr && _activeState != this )
      _activeState->tick();
  }
  
  double Complex::State_2::getTimerPeriod ( void ) {
    return timerPeriod;
  }
  
  bool Complex::State_2::handleEvent ( StateMachine::Event* event ) {
    bool handled = false;
  
    // take care of all event types that this branch will not handle -
    // for more consistent run-time performnace
    switch ( event->type() ) {
    case Event::Type::ENDEVENT:
      handled = true;
      break;
    case Event::Type::EVENT1:
      handled = true;
      break;
    default:
      break;
    }
  
    if (handled) {
      // we didn't actually handle the event, but return anyway
      return false;
    }
  
    // handle internal transitions first
    switch ( event->type() ) {
    default:
      break;
    }
    if (!handled) {
      // handle external transitions here
      switch ( event->type() ) {
      case Event::Type::EVENT4:
        if ( false ) { }  // makes generation easier :)
        else if ( true ) {
          #ifdef DEBUG_OUTPUT
          std::cout << "NO GUARD on EXTERNAL TRANSITION:/c/Q" << std::endl;
          #endif
          // Transitioning states!
          // Call all from prev state down exits
        COMPLEX_OBJ__STATE_2_OBJ->exitChildren();
        // State : exit for: /c/v
        COMPLEX_OBJ__STATE_2_OBJ->exit();
        // External Transition : Action for: /c/Q
        #ifdef DEBUG_OUTPUT
        std::cout << "TRANSITION::ACTION for /c/Q" << std::endl;
        #endif
        
        //::::/c/Q::::Action::::
        
        // State : entry for: /c/T
        COMPLEX_OBJ__STATE3_OBJ->entry();
        #ifdef DEBUG_OUTPUT
        std::cout << "STATE TRANSITION: Complex::State_2->Complex::State3::Deep_History_Pseudostate" << std::endl;
        #endif
        
          // going into deep history pseudo-state
          COMPLEX_OBJ__STATE3_OBJ->setDeepHistory();
          // make sure nothing else handles this event
          handled = true;
          }
        break;
      case Event::Type::EVENT2:
        if ( false ) { }  // makes generation easier :)
        else if ( true ) {
          #ifdef DEBUG_OUTPUT
          std::cout << "NO GUARD on EXTERNAL TRANSITION:/c/E" << std::endl;
          #endif
          // Transitioning states!
          // Call all from prev state down exits
        COMPLEX_OBJ__STATE_2_OBJ->exitChildren();
        // State : exit for: /c/v
        COMPLEX_OBJ__STATE_2_OBJ->exit();
        // External Transition : Action for: /c/E
        #ifdef DEBUG_OUTPUT
        std::cout << "TRANSITION::ACTION for /c/E" << std::endl;
        #endif
        
        //::::/c/E::::Action::::
        
        // State : entry for: /c/T
        COMPLEX_OBJ__STATE3_OBJ->entry();
        #ifdef DEBUG_OUTPUT
        std::cout << "STATE TRANSITION: Complex::State_2->Complex::State3" << std::endl;
        #endif
        
          // going into regular state
          COMPLEX_OBJ__STATE3_OBJ->initialize();
          // make sure nothing else handles this event
          handled = true;
          }
        break;
      case Event::Type::EVENT3:
        if ( false ) { }  // makes generation easier :)
        else if ( true ) {
          #ifdef DEBUG_OUTPUT
          std::cout << "NO GUARD on EXTERNAL TRANSITION:/c/t" << std::endl;
          #endif
          // Transitioning states!
          // Call all from prev state down exits
        COMPLEX_OBJ__STATE_2_OBJ->exitChildren();
        // State : exit for: /c/v
        COMPLEX_OBJ__STATE_2_OBJ->exit();
        // External Transition : Action for: /c/t
        #ifdef DEBUG_OUTPUT
        std::cout << "TRANSITION::ACTION for /c/t" << std::endl;
        #endif
        
        //::::/c/t::::Action::::
        
        // State : entry for: /c/T
        COMPLEX_OBJ__STATE3_OBJ->entry();
        #ifdef DEBUG_OUTPUT
        std::cout << "STATE TRANSITION: Complex::State_2->Complex::State3::Shallow_History_Pseudostate" << std::endl;
        #endif
        
          // going into shallow history pseudo-state
          COMPLEX_OBJ__STATE3_OBJ->setShallowHistory();
            // make sure nothing else handles this event
          handled = true;
          }
        break;
      default:
        break;
      }
    }
    // can't buble up, we are a root state.
    return handled;
  }
  /* * *  Definitions for Complex::State_2::ChildState : /c/v/K  * * */
  // Timer period
  const double Complex::State_2::ChildState::timerPeriod = 0.1;
  
  void Complex::State_2::ChildState::initialize ( void ) {
    // if we're a leaf state, make sure we're active
    makeActive();
  }
  
  void Complex::State_2::ChildState::entry ( void ) {
    #ifdef DEBUG_OUTPUT
    std::cout << "ENTRY::Complex::State_2::ChildState::/c/v/K" << std::endl;
    #endif
    // Entry action for this state
    //::::/c/v/K::::Entry::::
    
  }
  
  void Complex::State_2::ChildState::exit ( void ) {
    #ifdef DEBUG_OUTPUT
    std::cout << "EXIT::Complex::State_2::ChildState::/c/v/K" << std::endl;
    #endif
    // Call the Exit Action for this state
    //::::/c/v/K::::Exit::::
    
  }
  
  void Complex::State_2::ChildState::tick ( void ) {
    #ifdef DEBUG_OUTPUT
    std::cout << "TICK::Complex::State_2::ChildState::/c/v/K" << std::endl;
    #endif
    // Call the Tick Action for this state
    //::::/c/v/K::::Tick::::
    
    if ( _activeState != nullptr && _activeState != this )
      _activeState->tick();
  }
  
  double Complex::State_2::ChildState::getTimerPeriod ( void ) {
    return timerPeriod;
  }
  
  bool Complex::State_2::ChildState::handleEvent ( StateMachine::Event* event ) {
    bool handled = false;
  
    // take care of all event types that this branch will not handle -
    // for more consistent run-time performnace
    switch ( event->type() ) {
    case Event::Type::ENDEVENT:
      handled = true;
      break;
    default:
      break;
    }
  
    if (handled) {
      // we didn't actually handle the event, but return anyway
      return false;
    }
  
    // handle internal transitions first
    switch ( event->type() ) {
    default:
      break;
    }
    if (!handled) {
      // handle external transitions here
      switch ( event->type() ) {
      case Event::Type::EVENT1:
        if ( false ) { }  // makes generation easier :)
        else if ( true ) {
          #ifdef DEBUG_OUTPUT
          std::cout << "NO GUARD on EXTERNAL TRANSITION:/c/v/S" << std::endl;
          #endif
          // Transitioning states!
          // Call all from prev state down exits
        COMPLEX_OBJ__STATE_2_OBJ__CHILDSTATE_OBJ->exitChildren();
        // State : exit for: /c/v/K
        COMPLEX_OBJ__STATE_2_OBJ__CHILDSTATE_OBJ->exit();
        // External Transition : Action for: /c/v/S
        #ifdef DEBUG_OUTPUT
        std::cout << "TRANSITION::ACTION for /c/v/S" << std::endl;
        #endif
        
        //::::/c/v/S::::Action::::
        
        // State : entry for: /c/v/e
        COMPLEX_OBJ__STATE_2_OBJ__CHILDSTATE2_OBJ->entry();
        #ifdef DEBUG_OUTPUT
        std::cout << "STATE TRANSITION: Complex::State_2::ChildState->Complex::State_2::ChildState2" << std::endl;
        #endif
        
          // going into regular state
          COMPLEX_OBJ__STATE_2_OBJ__CHILDSTATE2_OBJ->initialize();
          // make sure nothing else handles this event
          handled = true;
          }
        break;
      default:
        break;
      }
    }
    if (!handled) {
      // now check parent states
      handled = _parentState->handleEvent( event );
    }
    return handled;
  }
  /* * *  Definitions for Complex::State_2::ChildState2 : /c/v/e  * * */
  // Timer period
  const double Complex::State_2::ChildState2::timerPeriod = 0.1;
  
  void Complex::State_2::ChildState2::initialize ( void ) {
    // if we're a leaf state, make sure we're active
    makeActive();
  }
  
  void Complex::State_2::ChildState2::entry ( void ) {
    #ifdef DEBUG_OUTPUT
    std::cout << "ENTRY::Complex::State_2::ChildState2::/c/v/e" << std::endl;
    #endif
    // Entry action for this state
    //::::/c/v/e::::Entry::::
    
  }
  
  void Complex::State_2::ChildState2::exit ( void ) {
    #ifdef DEBUG_OUTPUT
    std::cout << "EXIT::Complex::State_2::ChildState2::/c/v/e" << std::endl;
    #endif
    // Call the Exit Action for this state
    //::::/c/v/e::::Exit::::
    
  }
  
  void Complex::State_2::ChildState2::tick ( void ) {
    #ifdef DEBUG_OUTPUT
    std::cout << "TICK::Complex::State_2::ChildState2::/c/v/e" << std::endl;
    #endif
    // Call the Tick Action for this state
    //::::/c/v/e::::Tick::::
    
    if ( _activeState != nullptr && _activeState != this )
      _activeState->tick();
  }
  
  double Complex::State_2::ChildState2::getTimerPeriod ( void ) {
    return timerPeriod;
  }
  
  bool Complex::State_2::ChildState2::handleEvent ( StateMachine::Event* event ) {
    bool handled = false;
  
    // take care of all event types that this branch will not handle -
    // for more consistent run-time performnace
    switch ( event->type() ) {
    case Event::Type::ENDEVENT:
      handled = true;
      break;
    case Event::Type::EVENT1:
      handled = true;
      break;
    default:
      break;
    }
  
    if (handled) {
      // we didn't actually handle the event, but return anyway
      return false;
    }
  
    // handle internal transitions first
    switch ( event->type() ) {
    default:
      break;
    }
    if (!handled) {
      // handle external transitions here
      switch ( event->type() ) {
      case Event::Type::EVENT2:
        if ( false ) { }  // makes generation easier :)
        else if ( true ) {
          #ifdef DEBUG_OUTPUT
          std::cout << "NO GUARD on EXTERNAL TRANSITION:/c/v/W" << std::endl;
          #endif
          // Transitioning states!
          // Call all from prev state down exits
        COMPLEX_OBJ__STATE_2_OBJ__CHILDSTATE2_OBJ->exitChildren();
        // State : exit for: /c/v/e
        COMPLEX_OBJ__STATE_2_OBJ__CHILDSTATE2_OBJ->exit();
        // External Transition : Action for: /c/v/W
        #ifdef DEBUG_OUTPUT
        std::cout << "TRANSITION::ACTION for /c/v/W" << std::endl;
        #endif
        
        //::::/c/v/W::::Action::::
        
        // State : entry for: /c/v/z
        COMPLEX_OBJ__STATE_2_OBJ__CHILDSTATE3_OBJ->entry();
        #ifdef DEBUG_OUTPUT
        std::cout << "STATE TRANSITION: Complex::State_2::ChildState2->Complex::State_2::ChildState3" << std::endl;
        #endif
        
          // going into regular state
          COMPLEX_OBJ__STATE_2_OBJ__CHILDSTATE3_OBJ->initialize();
          // make sure nothing else handles this event
          handled = true;
          }
        break;
      default:
        break;
      }
    }
    if (!handled) {
      // now check parent states
      handled = _parentState->handleEvent( event );
    }
    return handled;
  }
  /* * *  Definitions for Complex::State_2::ChildState3 : /c/v/z  * * */
  // Timer period
  const double Complex::State_2::ChildState3::timerPeriod = 0;
  
  void Complex::State_2::ChildState3::initialize ( void ) {
    // External Transition : Action for: /c/v/z/8
    #ifdef DEBUG_OUTPUT
    std::cout << "TRANSITION::ACTION for /c/v/z/8" << std::endl;
    #endif
    
    //::::/c/v/z/8::::Action::::
    
    // State : entry for: /c/v/z/6
    COMPLEX_OBJ__STATE_2_OBJ__CHILDSTATE3_OBJ__GRAND_OBJ->entry();
    
    // initialize our new active state
    COMPLEX_OBJ__STATE_2_OBJ__CHILDSTATE3_OBJ__GRAND_OBJ->initialize();
  }
  
  void Complex::State_2::ChildState3::entry ( void ) {
    #ifdef DEBUG_OUTPUT
    std::cout << "ENTRY::Complex::State_2::ChildState3::/c/v/z" << std::endl;
    #endif
    // Entry action for this state
    //::::/c/v/z::::Entry::::
    
  }
  
  void Complex::State_2::ChildState3::exit ( void ) {
    #ifdef DEBUG_OUTPUT
    std::cout << "EXIT::Complex::State_2::ChildState3::/c/v/z" << std::endl;
    #endif
    // Call the Exit Action for this state
    //::::/c/v/z::::Exit::::
    
  }
  
  void Complex::State_2::ChildState3::tick ( void ) {
    #ifdef DEBUG_OUTPUT
    std::cout << "TICK::Complex::State_2::ChildState3::/c/v/z" << std::endl;
    #endif
    // Call the Tick Action for this state
    //::::/c/v/z::::Tick::::
    
    if ( _activeState != nullptr && _activeState != this )
      _activeState->tick();
  }
  
  double Complex::State_2::ChildState3::getTimerPeriod ( void ) {
    return timerPeriod;
  }
  
  bool Complex::State_2::ChildState3::handleEvent ( StateMachine::Event* event ) {
    bool handled = false;
  
    // take care of all event types that this branch will not handle -
    // for more consistent run-time performnace
    switch ( event->type() ) {
    case Event::Type::ENDEVENT:
      handled = true;
      break;
    case Event::Type::EVENT1:
      handled = true;
      break;
    default:
      break;
    }
  
    if (handled) {
      // we didn't actually handle the event, but return anyway
      return false;
    }
  
    // handle internal transitions first
    switch ( event->type() ) {
    default:
      break;
    }
    if (!handled) {
      // handle external transitions here
      switch ( event->type() ) {
      case Event::Type::EVENT3:
        if ( false ) { }  // makes generation easier :)
        //::::/c/v/P::::Guard::::
        else if ( someGuard ) {
          #ifdef DEBUG_OUTPUT
          std::cout << "GUARD [ someGuard ] for EXTERNAL TRANSITION:/c/v/P evaluated to TRUE" << std::endl;
          #endif
          // Transitioning states!
          // Call all from prev state down exits
        COMPLEX_OBJ__STATE_2_OBJ__CHILDSTATE3_OBJ->exitChildren();
        // State : exit for: /c/v/z
        COMPLEX_OBJ__STATE_2_OBJ__CHILDSTATE3_OBJ->exit();
        // External Transition : Action for: /c/v/P
        #ifdef DEBUG_OUTPUT
        std::cout << "TRANSITION::ACTION for /c/v/P" << std::endl;
        #endif
        
        //::::/c/v/P::::Action::::
        
        // State : entry for: /c/v/K
        COMPLEX_OBJ__STATE_2_OBJ__CHILDSTATE_OBJ->entry();
        #ifdef DEBUG_OUTPUT
        std::cout << "STATE TRANSITION: Complex::State_2::ChildState3->Complex::State_2::ChildState" << std::endl;
        #endif
        
          // going into regular state
          COMPLEX_OBJ__STATE_2_OBJ__CHILDSTATE_OBJ->initialize();
          // make sure nothing else handles this event
          handled = true;
          }
        break;
      default:
        break;
      }
    }
    if (!handled) {
      // now check parent states
      handled = _parentState->handleEvent( event );
    }
    return handled;
  }
  /* * *  Definitions for Complex::State_2::ChildState3::Grand : /c/v/z/6  * * */
  // Timer period
  const double Complex::State_2::ChildState3::Grand::timerPeriod = 0.1;
  
  void Complex::State_2::ChildState3::Grand::initialize ( void ) {
    // if we're a leaf state, make sure we're active
    makeActive();
  }
  
  void Complex::State_2::ChildState3::Grand::entry ( void ) {
    #ifdef DEBUG_OUTPUT
    std::cout << "ENTRY::Complex::State_2::ChildState3::Grand::/c/v/z/6" << std::endl;
    #endif
    // Entry action for this state
    //::::/c/v/z/6::::Entry::::
    
  }
  
  void Complex::State_2::ChildState3::Grand::exit ( void ) {
    #ifdef DEBUG_OUTPUT
    std::cout << "EXIT::Complex::State_2::ChildState3::Grand::/c/v/z/6" << std::endl;
    #endif
    // Call the Exit Action for this state
    //::::/c/v/z/6::::Exit::::
    
  }
  
  void Complex::State_2::ChildState3::Grand::tick ( void ) {
    #ifdef DEBUG_OUTPUT
    std::cout << "TICK::Complex::State_2::ChildState3::Grand::/c/v/z/6" << std::endl;
    #endif
    // Call the Tick Action for this state
    //::::/c/v/z/6::::Tick::::
    
    if ( _activeState != nullptr && _activeState != this )
      _activeState->tick();
  }
  
  double Complex::State_2::ChildState3::Grand::getTimerPeriod ( void ) {
    return timerPeriod;
  }
  
  bool Complex::State_2::ChildState3::Grand::handleEvent ( StateMachine::Event* event ) {
    bool handled = false;
  
    // take care of all event types that this branch will not handle -
    // for more consistent run-time performnace
    switch ( event->type() ) {
    case Event::Type::ENDEVENT:
      handled = true;
      break;
    default:
      break;
    }
  
    if (handled) {
      // we didn't actually handle the event, but return anyway
      return false;
    }
  
    // handle internal transitions first
    switch ( event->type() ) {
    default:
      break;
    }
    if (!handled) {
      // handle external transitions here
      switch ( event->type() ) {
      case Event::Type::EVENT1:
        if ( false ) { }  // makes generation easier :)
        else if ( true ) {
          #ifdef DEBUG_OUTPUT
          std::cout << "NO GUARD on EXTERNAL TRANSITION:/c/v/z/z" << std::endl;
          #endif
          // Transitioning states!
          // Call all from prev state down exits
        COMPLEX_OBJ__STATE_2_OBJ__CHILDSTATE3_OBJ__GRAND_OBJ->exitChildren();
        // State : exit for: /c/v/z/6
        COMPLEX_OBJ__STATE_2_OBJ__CHILDSTATE3_OBJ__GRAND_OBJ->exit();
        // External Transition : Action for: /c/v/z/z
        #ifdef DEBUG_OUTPUT
        std::cout << "TRANSITION::ACTION for /c/v/z/z" << std::endl;
        #endif
        
        //::::/c/v/z/z::::Action::::
        
        // State : entry for: /c/v/z/c
        COMPLEX_OBJ__STATE_2_OBJ__CHILDSTATE3_OBJ__GRAND2_OBJ->entry();
        #ifdef DEBUG_OUTPUT
        std::cout << "STATE TRANSITION: Complex::State_2::ChildState3::Grand->Complex::State_2::ChildState3::Grand2" << std::endl;
        #endif
        
          // going into regular state
          COMPLEX_OBJ__STATE_2_OBJ__CHILDSTATE3_OBJ__GRAND2_OBJ->initialize();
          // make sure nothing else handles this event
          handled = true;
          }
        break;
      default:
        break;
      }
    }
    if (!handled) {
      // now check parent states
      handled = _parentState->handleEvent( event );
    }
    return handled;
  }
  /* * *  Definitions for Complex::State_2::ChildState3::Grand2 : /c/v/z/c  * * */
  // Timer period
  const double Complex::State_2::ChildState3::Grand2::timerPeriod = 0.1;
  
  void Complex::State_2::ChildState3::Grand2::initialize ( void ) {
    // if we're a leaf state, make sure we're active
    makeActive();
  }
  
  void Complex::State_2::ChildState3::Grand2::entry ( void ) {
    #ifdef DEBUG_OUTPUT
    std::cout << "ENTRY::Complex::State_2::ChildState3::Grand2::/c/v/z/c" << std::endl;
    #endif
    // Entry action for this state
    //::::/c/v/z/c::::Entry::::
    
  }
  
  void Complex::State_2::ChildState3::Grand2::exit ( void ) {
    #ifdef DEBUG_OUTPUT
    std::cout << "EXIT::Complex::State_2::ChildState3::Grand2::/c/v/z/c" << std::endl;
    #endif
    // Call the Exit Action for this state
    //::::/c/v/z/c::::Exit::::
    
  }
  
  void Complex::State_2::ChildState3::Grand2::tick ( void ) {
    #ifdef DEBUG_OUTPUT
    std::cout << "TICK::Complex::State_2::ChildState3::Grand2::/c/v/z/c" << std::endl;
    #endif
    // Call the Tick Action for this state
    //::::/c/v/z/c::::Tick::::
    
    if ( _activeState != nullptr && _activeState != this )
      _activeState->tick();
  }
  
  double Complex::State_2::ChildState3::Grand2::getTimerPeriod ( void ) {
    return timerPeriod;
  }
  
  bool Complex::State_2::ChildState3::Grand2::handleEvent ( StateMachine::Event* event ) {
    bool handled = false;
  
    // take care of all event types that this branch will not handle -
    // for more consistent run-time performnace
    switch ( event->type() ) {
    default:
      break;
    }
  
    if (handled) {
      // we didn't actually handle the event, but return anyway
      return false;
    }
  
    // handle internal transitions first
    switch ( event->type() ) {
    default:
      break;
    }
    if (!handled) {
      // handle external transitions here
      switch ( event->type() ) {
      case Event::Type::ENDEVENT:
        if ( false ) { }  // makes generation easier :)
        else if ( true ) {
          #ifdef DEBUG_OUTPUT
          std::cout << "NO GUARD on EXTERNAL TRANSITION:/c/v/z/9" << std::endl;
          #endif
          // Going into an end pseudo-state that is not the root end state,
          // follow its parent end transition
          if (false) { }
          else if ( true ) {
            #ifdef DEBUG_OUTPUT
            std::cout << "NO GUARD on EXTERNAL TRANSITION:/c/v/F" << std::endl;
            #endif
            // Going into a choice pseudo-state, let it handle its
            // guards and perform the state transition
            if (false) { } // makes geneeration easier :)
            //::::/c/v/g::::Guard::::
            else if ( killedState ) {
              #ifdef DEBUG_OUTPUT
              std::cout << "GUARD [ killedState ] for EXTERNAL TRANSITION:/c/v/g evaluated to TRUE" << std::endl;
              #endif
              // Going into an end pseudo-state that is not the root end state,
              // follow its parent end transition
              if (false) { }
              else if ( true ) {
                #ifdef DEBUG_OUTPUT
                std::cout << "NO GUARD on EXTERNAL TRANSITION:/c/F" << std::endl;
                #endif
                // Transitioning states!
                // Call all from prev state down exits
              COMPLEX_OBJ__STATE_2_OBJ__CHILDSTATE3_OBJ__GRAND2_OBJ->exitChildren();
              // State : exit for: /c/v/z/c
              COMPLEX_OBJ__STATE_2_OBJ__CHILDSTATE3_OBJ__GRAND2_OBJ->exit();
              // State : exit for: /c/v/z
              COMPLEX_OBJ__STATE_2_OBJ__CHILDSTATE3_OBJ->exit();
              // State : exit for: /c/v
              COMPLEX_OBJ__STATE_2_OBJ->exit();
              // External Transition : Action for: /c/v/z/9
              #ifdef DEBUG_OUTPUT
              std::cout << "TRANSITION::ACTION for /c/v/z/9" << std::endl;
              #endif
              
              //::::/c/v/z/9::::Action::::
              
              // External Transition : Action for: /c/v/F
              #ifdef DEBUG_OUTPUT
              std::cout << "TRANSITION::ACTION for /c/v/F" << std::endl;
              #endif
              
              //::::/c/v/F::::Action::::
              
              // External Transition : Action for: /c/v/g
              #ifdef DEBUG_OUTPUT
              std::cout << "TRANSITION::ACTION for /c/v/g" << std::endl;
              #endif
              
              //::::/c/v/g::::Action::::
              
              // External Transition : Action for: /c/F
              #ifdef DEBUG_OUTPUT
              std::cout << "TRANSITION::ACTION for /c/F" << std::endl;
              #endif
              
              //::::/c/F::::Action::::
              
              #ifdef DEBUG_OUTPUT
              std::cout << "STATE TRANSITION: Complex::State_2::ChildState3::Grand2->Complex::End_State" << std::endl;
              #endif
              
                // going into end pseudo-state THIS SHOULD BE TOP LEVEL END STATE
                COMPLEX_OBJ__END_STATE_OBJ->makeActive();
                // make sure nothing else handles this event
                handled = true;
                }
            }
            else if ( true ) {
              #ifdef DEBUG_OUTPUT
              std::cout << "NO GUARD on EXTERNAL TRANSITION:/c/v/2" << std::endl;
              #endif
              // Transitioning states!
              // Call all from prev state down exits
            COMPLEX_OBJ__STATE_2_OBJ__CHILDSTATE3_OBJ__GRAND2_OBJ->exitChildren();
            // State : exit for: /c/v/z/c
            COMPLEX_OBJ__STATE_2_OBJ__CHILDSTATE3_OBJ__GRAND2_OBJ->exit();
            // State : exit for: /c/v/z
            COMPLEX_OBJ__STATE_2_OBJ__CHILDSTATE3_OBJ->exit();
            // External Transition : Action for: /c/v/z/9
            #ifdef DEBUG_OUTPUT
            std::cout << "TRANSITION::ACTION for /c/v/z/9" << std::endl;
            #endif
            
            //::::/c/v/z/9::::Action::::
            
            // External Transition : Action for: /c/v/F
            #ifdef DEBUG_OUTPUT
            std::cout << "TRANSITION::ACTION for /c/v/F" << std::endl;
            #endif
            
            //::::/c/v/F::::Action::::
            
            // External Transition : Action for: /c/v/2
            #ifdef DEBUG_OUTPUT
            std::cout << "TRANSITION::ACTION for /c/v/2" << std::endl;
            #endif
            
            //::::/c/v/2::::Action::::
            
            // State : entry for: /c/v/z
            COMPLEX_OBJ__STATE_2_OBJ__CHILDSTATE3_OBJ->entry();
            #ifdef DEBUG_OUTPUT
            std::cout << "STATE TRANSITION: Complex::State_2::ChildState3::Grand2->Complex::State_2::ChildState3" << std::endl;
            #endif
            
              // going into regular state
              COMPLEX_OBJ__STATE_2_OBJ__CHILDSTATE3_OBJ->initialize();
              // make sure nothing else handles this event
              handled = true;
              }
          }
        }
        break;
      case Event::Type::EVENT2:
        if ( false ) { }  // makes generation easier :)
        else if ( true ) {
          #ifdef DEBUG_OUTPUT
          std::cout << "NO GUARD on EXTERNAL TRANSITION:/c/v/z/R" << std::endl;
          #endif
          // Going into a choice pseudo-state, let it handle its
          // guards and perform the state transition
          if (false) { } // makes geneeration easier :)
          //::::/c/v/z/j::::Guard::::
          else if ( goToEnd ) {
            #ifdef DEBUG_OUTPUT
            std::cout << "GUARD [ goToEnd ] for EXTERNAL TRANSITION:/c/v/z/j evaluated to TRUE" << std::endl;
            #endif
            // Going into an end pseudo-state that is not the root end state,
            // follow its parent end transition
            if (false) { }
            else if ( true ) {
              #ifdef DEBUG_OUTPUT
              std::cout << "NO GUARD on EXTERNAL TRANSITION:/c/v/F" << std::endl;
              #endif
              // Going into a choice pseudo-state, let it handle its
              // guards and perform the state transition
              if (false) { } // makes geneeration easier :)
              //::::/c/v/g::::Guard::::
              else if ( killedState ) {
                #ifdef DEBUG_OUTPUT
                std::cout << "GUARD [ killedState ] for EXTERNAL TRANSITION:/c/v/g evaluated to TRUE" << std::endl;
                #endif
                // Going into an end pseudo-state that is not the root end state,
                // follow its parent end transition
                if (false) { }
                else if ( true ) {
                  #ifdef DEBUG_OUTPUT
                  std::cout << "NO GUARD on EXTERNAL TRANSITION:/c/F" << std::endl;
                  #endif
                  // Transitioning states!
                  // Call all from prev state down exits
                COMPLEX_OBJ__STATE_2_OBJ__CHILDSTATE3_OBJ__GRAND2_OBJ->exitChildren();
                // State : exit for: /c/v/z/c
                COMPLEX_OBJ__STATE_2_OBJ__CHILDSTATE3_OBJ__GRAND2_OBJ->exit();
                // State : exit for: /c/v/z
                COMPLEX_OBJ__STATE_2_OBJ__CHILDSTATE3_OBJ->exit();
                // State : exit for: /c/v
                COMPLEX_OBJ__STATE_2_OBJ->exit();
                // External Transition : Action for: /c/v/z/R
                #ifdef DEBUG_OUTPUT
                std::cout << "TRANSITION::ACTION for /c/v/z/R" << std::endl;
                #endif
                
                //::::/c/v/z/R::::Action::::
                
                // External Transition : Action for: /c/v/z/j
                #ifdef DEBUG_OUTPUT
                std::cout << "TRANSITION::ACTION for /c/v/z/j" << std::endl;
                #endif
                
                //::::/c/v/z/j::::Action::::
                
                // External Transition : Action for: /c/v/F
                #ifdef DEBUG_OUTPUT
                std::cout << "TRANSITION::ACTION for /c/v/F" << std::endl;
                #endif
                
                //::::/c/v/F::::Action::::
                
                // External Transition : Action for: /c/v/g
                #ifdef DEBUG_OUTPUT
                std::cout << "TRANSITION::ACTION for /c/v/g" << std::endl;
                #endif
                
                //::::/c/v/g::::Action::::
                
                // External Transition : Action for: /c/F
                #ifdef DEBUG_OUTPUT
                std::cout << "TRANSITION::ACTION for /c/F" << std::endl;
                #endif
                
                //::::/c/F::::Action::::
                
                #ifdef DEBUG_OUTPUT
                std::cout << "STATE TRANSITION: Complex::State_2::ChildState3::Grand2->Complex::End_State" << std::endl;
                #endif
                
                  // going into end pseudo-state THIS SHOULD BE TOP LEVEL END STATE
                  COMPLEX_OBJ__END_STATE_OBJ->makeActive();
                  // make sure nothing else handles this event
                  handled = true;
                  }
              }
              else if ( true ) {
                #ifdef DEBUG_OUTPUT
                std::cout << "NO GUARD on EXTERNAL TRANSITION:/c/v/2" << std::endl;
                #endif
                // Transitioning states!
                // Call all from prev state down exits
              COMPLEX_OBJ__STATE_2_OBJ__CHILDSTATE3_OBJ__GRAND2_OBJ->exitChildren();
              // State : exit for: /c/v/z/c
              COMPLEX_OBJ__STATE_2_OBJ__CHILDSTATE3_OBJ__GRAND2_OBJ->exit();
              // State : exit for: /c/v/z
              COMPLEX_OBJ__STATE_2_OBJ__CHILDSTATE3_OBJ->exit();
              // External Transition : Action for: /c/v/z/R
              #ifdef DEBUG_OUTPUT
              std::cout << "TRANSITION::ACTION for /c/v/z/R" << std::endl;
              #endif
              
              //::::/c/v/z/R::::Action::::
              
              // External Transition : Action for: /c/v/z/j
              #ifdef DEBUG_OUTPUT
              std::cout << "TRANSITION::ACTION for /c/v/z/j" << std::endl;
              #endif
              
              //::::/c/v/z/j::::Action::::
              
              // External Transition : Action for: /c/v/F
              #ifdef DEBUG_OUTPUT
              std::cout << "TRANSITION::ACTION for /c/v/F" << std::endl;
              #endif
              
              //::::/c/v/F::::Action::::
              
              // External Transition : Action for: /c/v/2
              #ifdef DEBUG_OUTPUT
              std::cout << "TRANSITION::ACTION for /c/v/2" << std::endl;
              #endif
              
              //::::/c/v/2::::Action::::
              
              // State : entry for: /c/v/z
              COMPLEX_OBJ__STATE_2_OBJ__CHILDSTATE3_OBJ->entry();
              #ifdef DEBUG_OUTPUT
              std::cout << "STATE TRANSITION: Complex::State_2::ChildState3::Grand2->Complex::State_2::ChildState3" << std::endl;
              #endif
              
                // going into regular state
                COMPLEX_OBJ__STATE_2_OBJ__CHILDSTATE3_OBJ->initialize();
                // make sure nothing else handles this event
                handled = true;
                }
            }
          }
          //::::/c/v/z/g::::Guard::::
          else if ( goToChoice ) {
            #ifdef DEBUG_OUTPUT
            std::cout << "GUARD [ goToChoice ] for EXTERNAL TRANSITION:/c/v/z/g evaluated to TRUE" << std::endl;
            #endif
            // Going into a choice pseudo-state, let it handle its
            // guards and perform the state transition
            if (false) { } // makes geneeration easier :)
            //::::/c/h::::Guard::::
            else if ( goToHistory ) {
              #ifdef DEBUG_OUTPUT
              std::cout << "GUARD [ goToHistory ] for EXTERNAL TRANSITION:/c/h evaluated to TRUE" << std::endl;
              #endif
              // Transitioning states!
              // Call all from prev state down exits
            COMPLEX_OBJ__STATE_2_OBJ__CHILDSTATE3_OBJ__GRAND2_OBJ->exitChildren();
            // State : exit for: /c/v/z/c
            COMPLEX_OBJ__STATE_2_OBJ__CHILDSTATE3_OBJ__GRAND2_OBJ->exit();
            // State : exit for: /c/v/z
            COMPLEX_OBJ__STATE_2_OBJ__CHILDSTATE3_OBJ->exit();
            // State : exit for: /c/v
            COMPLEX_OBJ__STATE_2_OBJ->exit();
            // External Transition : Action for: /c/v/z/R
            #ifdef DEBUG_OUTPUT
            std::cout << "TRANSITION::ACTION for /c/v/z/R" << std::endl;
            #endif
            
            //::::/c/v/z/R::::Action::::
            
            // External Transition : Action for: /c/v/z/g
            #ifdef DEBUG_OUTPUT
            std::cout << "TRANSITION::ACTION for /c/v/z/g" << std::endl;
            #endif
            
            //::::/c/v/z/g::::Action::::
            
            // External Transition : Action for: /c/h
            #ifdef DEBUG_OUTPUT
            std::cout << "TRANSITION::ACTION for /c/h" << std::endl;
            #endif
            
            //::::/c/h::::Action::::
            
            // State : entry for: /c/T
            COMPLEX_OBJ__STATE3_OBJ->entry();
            #ifdef DEBUG_OUTPUT
            std::cout << "STATE TRANSITION: Complex::State_2::ChildState3::Grand2->Complex::State3::Shallow_History_Pseudostate" << std::endl;
            #endif
            
              // going into shallow history pseudo-state
              COMPLEX_OBJ__STATE3_OBJ->setShallowHistory();
                // make sure nothing else handles this event
              handled = true;
              }
            //::::/c/k::::Guard::::
            else if ( nextState ) {
              #ifdef DEBUG_OUTPUT
              std::cout << "GUARD [ nextState ] for EXTERNAL TRANSITION:/c/k evaluated to TRUE" << std::endl;
              #endif
              // Transitioning states!
              // Call all from prev state down exits
            COMPLEX_OBJ__STATE_2_OBJ__CHILDSTATE3_OBJ__GRAND2_OBJ->exitChildren();
            // State : exit for: /c/v/z/c
            COMPLEX_OBJ__STATE_2_OBJ__CHILDSTATE3_OBJ__GRAND2_OBJ->exit();
            // State : exit for: /c/v/z
            COMPLEX_OBJ__STATE_2_OBJ__CHILDSTATE3_OBJ->exit();
            // State : exit for: /c/v
            COMPLEX_OBJ__STATE_2_OBJ->exit();
            // External Transition : Action for: /c/v/z/R
            #ifdef DEBUG_OUTPUT
            std::cout << "TRANSITION::ACTION for /c/v/z/R" << std::endl;
            #endif
            
            //::::/c/v/z/R::::Action::::
            
            // External Transition : Action for: /c/v/z/g
            #ifdef DEBUG_OUTPUT
            std::cout << "TRANSITION::ACTION for /c/v/z/g" << std::endl;
            #endif
            
            //::::/c/v/z/g::::Action::::
            
            // External Transition : Action for: /c/k
            #ifdef DEBUG_OUTPUT
            std::cout << "TRANSITION::ACTION for /c/k" << std::endl;
            #endif
            
            //::::/c/k::::Action::::
            
            // State : entry for: /c/v
            COMPLEX_OBJ__STATE_2_OBJ->entry();
            #ifdef DEBUG_OUTPUT
            std::cout << "STATE TRANSITION: Complex::State_2::ChildState3::Grand2->Complex::State_2" << std::endl;
            #endif
            
              // going into regular state
              COMPLEX_OBJ__STATE_2_OBJ->initialize();
              // make sure nothing else handles this event
              handled = true;
              }
            else if ( true ) {
              #ifdef DEBUG_OUTPUT
              std::cout << "NO GUARD on EXTERNAL TRANSITION:/c/o" << std::endl;
              #endif
              // Transitioning states!
              // Call all from prev state down exits
            COMPLEX_OBJ__STATE_2_OBJ__CHILDSTATE3_OBJ__GRAND2_OBJ->exitChildren();
            // State : exit for: /c/v/z/c
            COMPLEX_OBJ__STATE_2_OBJ__CHILDSTATE3_OBJ__GRAND2_OBJ->exit();
            // State : exit for: /c/v/z
            COMPLEX_OBJ__STATE_2_OBJ__CHILDSTATE3_OBJ->exit();
            // State : exit for: /c/v
            COMPLEX_OBJ__STATE_2_OBJ->exit();
            // External Transition : Action for: /c/v/z/R
            #ifdef DEBUG_OUTPUT
            std::cout << "TRANSITION::ACTION for /c/v/z/R" << std::endl;
            #endif
            
            //::::/c/v/z/R::::Action::::
            
            // External Transition : Action for: /c/v/z/g
            #ifdef DEBUG_OUTPUT
            std::cout << "TRANSITION::ACTION for /c/v/z/g" << std::endl;
            #endif
            
            //::::/c/v/z/g::::Action::::
            
            // External Transition : Action for: /c/o
            #ifdef DEBUG_OUTPUT
            std::cout << "TRANSITION::ACTION for /c/o" << std::endl;
            #endif
            
            //::::/c/o::::Action::::
            
            // State : entry for: /c/T
            COMPLEX_OBJ__STATE3_OBJ->entry();
            #ifdef DEBUG_OUTPUT
            std::cout << "STATE TRANSITION: Complex::State_2::ChildState3::Grand2->Complex::State3" << std::endl;
            #endif
            
              // going into regular state
              COMPLEX_OBJ__STATE3_OBJ->initialize();
              // make sure nothing else handles this event
              handled = true;
              }
          }
          else if ( true ) {
            #ifdef DEBUG_OUTPUT
            std::cout << "NO GUARD on EXTERNAL TRANSITION:/c/v/z/O" << std::endl;
            #endif
            // Transitioning states!
            // Call all from prev state down exits
          COMPLEX_OBJ__STATE_2_OBJ__CHILDSTATE3_OBJ__GRAND2_OBJ->exitChildren();
          // State : exit for: /c/v/z/c
          COMPLEX_OBJ__STATE_2_OBJ__CHILDSTATE3_OBJ__GRAND2_OBJ->exit();
          // External Transition : Action for: /c/v/z/R
          #ifdef DEBUG_OUTPUT
          std::cout << "TRANSITION::ACTION for /c/v/z/R" << std::endl;
          #endif
          
          //::::/c/v/z/R::::Action::::
          
          // External Transition : Action for: /c/v/z/O
          #ifdef DEBUG_OUTPUT
          std::cout << "TRANSITION::ACTION for /c/v/z/O" << std::endl;
          #endif
          
          //::::/c/v/z/O::::Action::::
          
          // State : entry for: /c/v/z/c
          COMPLEX_OBJ__STATE_2_OBJ__CHILDSTATE3_OBJ__GRAND2_OBJ->entry();
          #ifdef DEBUG_OUTPUT
          std::cout << "STATE TRANSITION: Complex::State_2::ChildState3::Grand2->Complex::State_2::ChildState3::Grand2" << std::endl;
          #endif
          
            // going into regular state
            COMPLEX_OBJ__STATE_2_OBJ__CHILDSTATE3_OBJ__GRAND2_OBJ->initialize();
            // make sure nothing else handles this event
            handled = true;
            }
        }
        break;
      case Event::Type::EVENT1:
        if ( false ) { }  // makes generation easier :)
        else if ( true ) {
          #ifdef DEBUG_OUTPUT
          std::cout << "NO GUARD on EXTERNAL TRANSITION:/c/v/z/a" << std::endl;
          #endif
          // Transitioning states!
          // Call all from prev state down exits
        COMPLEX_OBJ__STATE_2_OBJ__CHILDSTATE3_OBJ__GRAND2_OBJ->exitChildren();
        // State : exit for: /c/v/z/c
        COMPLEX_OBJ__STATE_2_OBJ__CHILDSTATE3_OBJ__GRAND2_OBJ->exit();
        // External Transition : Action for: /c/v/z/a
        #ifdef DEBUG_OUTPUT
        std::cout << "TRANSITION::ACTION for /c/v/z/a" << std::endl;
        #endif
        
        //::::/c/v/z/a::::Action::::
        
        // State : entry for: /c/v/z/6
        COMPLEX_OBJ__STATE_2_OBJ__CHILDSTATE3_OBJ__GRAND_OBJ->entry();
        #ifdef DEBUG_OUTPUT
        std::cout << "STATE TRANSITION: Complex::State_2::ChildState3::Grand2->Complex::State_2::ChildState3::Grand" << std::endl;
        #endif
        
          // going into regular state
          COMPLEX_OBJ__STATE_2_OBJ__CHILDSTATE3_OBJ__GRAND_OBJ->initialize();
          // make sure nothing else handles this event
          handled = true;
          }
        break;
      default:
        break;
      }
    }
    if (!handled) {
      // now check parent states
      handled = _parentState->handleEvent( event );
    }
    return handled;
  }
  /* * *  Definitions for Complex::State3 : /c/T  * * */
  // Timer period
  const double Complex::State3::timerPeriod = 0;
  
  void Complex::State3::initialize ( void ) {
    // External Transition : Action for: /c/T/I
    #ifdef DEBUG_OUTPUT
    std::cout << "TRANSITION::ACTION for /c/T/I" << std::endl;
    #endif
    
    //::::/c/T/I::::Action::::
    
    // State : entry for: /c/T/W
    COMPLEX_OBJ__STATE3_OBJ__CHILDSTATE_OBJ->entry();
    
    // initialize our new active state
    COMPLEX_OBJ__STATE3_OBJ__CHILDSTATE_OBJ->initialize();
  }
  
  void Complex::State3::entry ( void ) {
    #ifdef DEBUG_OUTPUT
    std::cout << "ENTRY::Complex::State3::/c/T" << std::endl;
    #endif
    // Entry action for this state
    //::::/c/T::::Entry::::
    
  }
  
  void Complex::State3::exit ( void ) {
    #ifdef DEBUG_OUTPUT
    std::cout << "EXIT::Complex::State3::/c/T" << std::endl;
    #endif
    // Call the Exit Action for this state
    //::::/c/T::::Exit::::
    
  }
  
  void Complex::State3::tick ( void ) {
    #ifdef DEBUG_OUTPUT
    std::cout << "TICK::Complex::State3::/c/T" << std::endl;
    #endif
    // Call the Tick Action for this state
    //::::/c/T::::Tick::::
    
    if ( _activeState != nullptr && _activeState != this )
      _activeState->tick();
  }
  
  double Complex::State3::getTimerPeriod ( void ) {
    return timerPeriod;
  }
  
  bool Complex::State3::handleEvent ( StateMachine::Event* event ) {
    bool handled = false;
  
    // take care of all event types that this branch will not handle -
    // for more consistent run-time performnace
    switch ( event->type() ) {
    case Event::Type::EVENT1:
      handled = true;
      break;
    default:
      break;
    }
  
    if (handled) {
      // we didn't actually handle the event, but return anyway
      return false;
    }
  
    // handle internal transitions first
    switch ( event->type() ) {
    default:
      break;
    }
    if (!handled) {
      // handle external transitions here
      switch ( event->type() ) {
      case Event::Type::EVENT3:
        if ( false ) { }  // makes generation easier :)
        else if ( true ) {
          #ifdef DEBUG_OUTPUT
          std::cout << "NO GUARD on EXTERNAL TRANSITION:/c/C" << std::endl;
          #endif
          // Transitioning states!
          // Call all from prev state down exits
        COMPLEX_OBJ__STATE3_OBJ->exitChildren();
        // State : exit for: /c/T
        COMPLEX_OBJ__STATE3_OBJ->exit();
        // External Transition : Action for: /c/C
        #ifdef DEBUG_OUTPUT
        std::cout << "TRANSITION::ACTION for /c/C" << std::endl;
        #endif
        
        //::::/c/C::::Action::::
        
        // State : entry for: /c/v
        COMPLEX_OBJ__STATE_2_OBJ->entry();
        #ifdef DEBUG_OUTPUT
        std::cout << "STATE TRANSITION: Complex::State3->Complex::State_2::Shallow_History_Pseudostate" << std::endl;
        #endif
        
          // going into shallow history pseudo-state
          COMPLEX_OBJ__STATE_2_OBJ->setShallowHistory();
            // make sure nothing else handles this event
          handled = true;
          }
        break;
      case Event::Type::ENDEVENT:
        if ( false ) { }  // makes generation easier :)
        else if ( true ) {
          #ifdef DEBUG_OUTPUT
          std::cout << "NO GUARD on EXTERNAL TRANSITION:/c/L" << std::endl;
          #endif
          // Transitioning states!
          // Call all from prev state down exits
        COMPLEX_OBJ__STATE3_OBJ->exitChildren();
        // State : exit for: /c/T
        COMPLEX_OBJ__STATE3_OBJ->exit();
        // External Transition : Action for: /c/L
        #ifdef DEBUG_OUTPUT
        std::cout << "TRANSITION::ACTION for /c/L" << std::endl;
        #endif
        
        //::::/c/L::::Action::::
        
        // State : entry for: /c/Y
        COMPLEX_OBJ__STATE_1_OBJ->entry();
        #ifdef DEBUG_OUTPUT
        std::cout << "STATE TRANSITION: Complex::State3->Complex::State_1" << std::endl;
        #endif
        
          // going into regular state
          COMPLEX_OBJ__STATE_1_OBJ->initialize();
          // make sure nothing else handles this event
          handled = true;
          }
        break;
      case Event::Type::EVENT2:
        if ( false ) { }  // makes generation easier :)
        else if ( true ) {
          #ifdef DEBUG_OUTPUT
          std::cout << "NO GUARD on EXTERNAL TRANSITION:/c/z" << std::endl;
          #endif
          // Transitioning states!
          // Call all from prev state down exits
        COMPLEX_OBJ__STATE3_OBJ->exitChildren();
        // State : exit for: /c/T
        COMPLEX_OBJ__STATE3_OBJ->exit();
        // External Transition : Action for: /c/z
        #ifdef DEBUG_OUTPUT
        std::cout << "TRANSITION::ACTION for /c/z" << std::endl;
        #endif
        
        //::::/c/z::::Action::::
        
        // State : entry for: /c/v
        COMPLEX_OBJ__STATE_2_OBJ->entry();
        #ifdef DEBUG_OUTPUT
        std::cout << "STATE TRANSITION: Complex::State3->Complex::State_2" << std::endl;
        #endif
        
          // going into regular state
          COMPLEX_OBJ__STATE_2_OBJ->initialize();
          // make sure nothing else handles this event
          handled = true;
          }
        break;
      case Event::Type::EVENT4:
        if ( false ) { }  // makes generation easier :)
        else if ( true ) {
          #ifdef DEBUG_OUTPUT
          std::cout << "NO GUARD on EXTERNAL TRANSITION:/c/w" << std::endl;
          #endif
          // Transitioning states!
          // Call all from prev state down exits
        COMPLEX_OBJ__STATE3_OBJ->exitChildren();
        // State : exit for: /c/T
        COMPLEX_OBJ__STATE3_OBJ->exit();
        // External Transition : Action for: /c/w
        #ifdef DEBUG_OUTPUT
        std::cout << "TRANSITION::ACTION for /c/w" << std::endl;
        #endif
        
        //::::/c/w::::Action::::
        
        // State : entry for: /c/v
        COMPLEX_OBJ__STATE_2_OBJ->entry();
        #ifdef DEBUG_OUTPUT
        std::cout << "STATE TRANSITION: Complex::State3->Complex::State_2::Deep_History_Pseudostate" << std::endl;
        #endif
        
          // going into deep history pseudo-state
          COMPLEX_OBJ__STATE_2_OBJ->setDeepHistory();
          // make sure nothing else handles this event
          handled = true;
          }
        break;
      default:
        break;
      }
    }
    // can't buble up, we are a root state.
    return handled;
  }
  /* * *  Definitions for Complex::State3::ChildState2 : /c/T/0  * * */
  // Timer period
  const double Complex::State3::ChildState2::timerPeriod = 0.1;
  
  void Complex::State3::ChildState2::initialize ( void ) {
    // if we're a leaf state, make sure we're active
    makeActive();
  }
  
  void Complex::State3::ChildState2::entry ( void ) {
    #ifdef DEBUG_OUTPUT
    std::cout << "ENTRY::Complex::State3::ChildState2::/c/T/0" << std::endl;
    #endif
    // Entry action for this state
    //::::/c/T/0::::Entry::::
    
  }
  
  void Complex::State3::ChildState2::exit ( void ) {
    #ifdef DEBUG_OUTPUT
    std::cout << "EXIT::Complex::State3::ChildState2::/c/T/0" << std::endl;
    #endif
    // Call the Exit Action for this state
    //::::/c/T/0::::Exit::::
    
  }
  
  void Complex::State3::ChildState2::tick ( void ) {
    #ifdef DEBUG_OUTPUT
    std::cout << "TICK::Complex::State3::ChildState2::/c/T/0" << std::endl;
    #endif
    // Call the Tick Action for this state
    //::::/c/T/0::::Tick::::
    
    if ( _activeState != nullptr && _activeState != this )
      _activeState->tick();
  }
  
  double Complex::State3::ChildState2::getTimerPeriod ( void ) {
    return timerPeriod;
  }
  
  bool Complex::State3::ChildState2::handleEvent ( StateMachine::Event* event ) {
    bool handled = false;
  
    // take care of all event types that this branch will not handle -
    // for more consistent run-time performnace
    switch ( event->type() ) {
    case Event::Type::EVENT1:
      handled = true;
      break;
    default:
      break;
    }
  
    if (handled) {
      // we didn't actually handle the event, but return anyway
      return false;
    }
  
    // handle internal transitions first
    switch ( event->type() ) {
    default:
      break;
    }
    if (!handled) {
      // handle external transitions here
      switch ( event->type() ) {
      case Event::Type::ENDEVENT:
        if ( false ) { }  // makes generation easier :)
        else if ( true ) {
          #ifdef DEBUG_OUTPUT
          std::cout << "NO GUARD on EXTERNAL TRANSITION:/c/T/h" << std::endl;
          #endif
          // Going into an end pseudo-state that is not the root end state,
          // follow its parent end transition
          if (false) { }
          else if ( true ) {
            #ifdef DEBUG_OUTPUT
            std::cout << "NO GUARD on EXTERNAL TRANSITION:/c/A" << std::endl;
            #endif
            // Transitioning states!
            // Call all from prev state down exits
          COMPLEX_OBJ__STATE3_OBJ__CHILDSTATE2_OBJ->exitChildren();
          // State : exit for: /c/T/0
          COMPLEX_OBJ__STATE3_OBJ__CHILDSTATE2_OBJ->exit();
          // State : exit for: /c/T
          COMPLEX_OBJ__STATE3_OBJ->exit();
          // External Transition : Action for: /c/T/h
          #ifdef DEBUG_OUTPUT
          std::cout << "TRANSITION::ACTION for /c/T/h" << std::endl;
          #endif
          
          //::::/c/T/h::::Action::::
          
          // External Transition : Action for: /c/A
          #ifdef DEBUG_OUTPUT
          std::cout << "TRANSITION::ACTION for /c/A" << std::endl;
          #endif
          
          //::::/c/A::::Action::::
          
          #ifdef DEBUG_OUTPUT
          std::cout << "STATE TRANSITION: Complex::State3::ChildState2->Complex::End_State" << std::endl;
          #endif
          
            // going into end pseudo-state THIS SHOULD BE TOP LEVEL END STATE
            COMPLEX_OBJ__END_STATE_OBJ->makeActive();
            // make sure nothing else handles this event
            handled = true;
            }
        }
        break;
      case Event::Type::EVENT2:
        if ( false ) { }  // makes generation easier :)
        else if ( true ) {
          #ifdef DEBUG_OUTPUT
          std::cout << "NO GUARD on EXTERNAL TRANSITION:/c/T/j" << std::endl;
          #endif
          // Transitioning states!
          // Call all from prev state down exits
        COMPLEX_OBJ__STATE3_OBJ__CHILDSTATE2_OBJ->exitChildren();
        // State : exit for: /c/T/0
        COMPLEX_OBJ__STATE3_OBJ__CHILDSTATE2_OBJ->exit();
        // External Transition : Action for: /c/T/j
        #ifdef DEBUG_OUTPUT
        std::cout << "TRANSITION::ACTION for /c/T/j" << std::endl;
        #endif
        
        //::::/c/T/j::::Action::::
        
        // State : entry for: /c/T/w
        COMPLEX_OBJ__STATE3_OBJ__CHILDSTATE3_OBJ->entry();
        #ifdef DEBUG_OUTPUT
        std::cout << "STATE TRANSITION: Complex::State3::ChildState2->Complex::State3::ChildState3" << std::endl;
        #endif
        
          // going into regular state
          COMPLEX_OBJ__STATE3_OBJ__CHILDSTATE3_OBJ->initialize();
          // make sure nothing else handles this event
          handled = true;
          }
        break;
      default:
        break;
      }
    }
    if (!handled) {
      // now check parent states
      handled = _parentState->handleEvent( event );
    }
    return handled;
  }
  /* * *  Definitions for Complex::State3::ChildState : /c/T/W  * * */
  // Timer period
  const double Complex::State3::ChildState::timerPeriod = 0.1;
  
  void Complex::State3::ChildState::initialize ( void ) {
    // if we're a leaf state, make sure we're active
    makeActive();
  }
  
  void Complex::State3::ChildState::entry ( void ) {
    #ifdef DEBUG_OUTPUT
    std::cout << "ENTRY::Complex::State3::ChildState::/c/T/W" << std::endl;
    #endif
    // Entry action for this state
    //::::/c/T/W::::Entry::::
    
  }
  
  void Complex::State3::ChildState::exit ( void ) {
    #ifdef DEBUG_OUTPUT
    std::cout << "EXIT::Complex::State3::ChildState::/c/T/W" << std::endl;
    #endif
    // Call the Exit Action for this state
    //::::/c/T/W::::Exit::::
    
  }
  
  void Complex::State3::ChildState::tick ( void ) {
    #ifdef DEBUG_OUTPUT
    std::cout << "TICK::Complex::State3::ChildState::/c/T/W" << std::endl;
    #endif
    // Call the Tick Action for this state
    //::::/c/T/W::::Tick::::
    
    if ( _activeState != nullptr && _activeState != this )
      _activeState->tick();
  }
  
  double Complex::State3::ChildState::getTimerPeriod ( void ) {
    return timerPeriod;
  }
  
  bool Complex::State3::ChildState::handleEvent ( StateMachine::Event* event ) {
    bool handled = false;
  
    // take care of all event types that this branch will not handle -
    // for more consistent run-time performnace
    switch ( event->type() ) {
    default:
      break;
    }
  
    if (handled) {
      // we didn't actually handle the event, but return anyway
      return false;
    }
  
    // handle internal transitions first
    switch ( event->type() ) {
    default:
      break;
    }
    if (!handled) {
      // handle external transitions here
      switch ( event->type() ) {
      case Event::Type::EVENT1:
        if ( false ) { }  // makes generation easier :)
        else if ( true ) {
          #ifdef DEBUG_OUTPUT
          std::cout << "NO GUARD on EXTERNAL TRANSITION:/c/T/L" << std::endl;
          #endif
          // Transitioning states!
          // Call all from prev state down exits
        COMPLEX_OBJ__STATE3_OBJ__CHILDSTATE_OBJ->exitChildren();
        // State : exit for: /c/T/W
        COMPLEX_OBJ__STATE3_OBJ__CHILDSTATE_OBJ->exit();
        // External Transition : Action for: /c/T/L
        #ifdef DEBUG_OUTPUT
        std::cout << "TRANSITION::ACTION for /c/T/L" << std::endl;
        #endif
        
        //::::/c/T/L::::Action::::
        
        // State : entry for: /c/T/0
        COMPLEX_OBJ__STATE3_OBJ__CHILDSTATE2_OBJ->entry();
        #ifdef DEBUG_OUTPUT
        std::cout << "STATE TRANSITION: Complex::State3::ChildState->Complex::State3::ChildState2" << std::endl;
        #endif
        
          // going into regular state
          COMPLEX_OBJ__STATE3_OBJ__CHILDSTATE2_OBJ->initialize();
          // make sure nothing else handles this event
          handled = true;
          }
        break;
      default:
        break;
      }
    }
    if (!handled) {
      // now check parent states
      handled = _parentState->handleEvent( event );
    }
    return handled;
  }
  /* * *  Definitions for Complex::State3::ChildState3 : /c/T/w  * * */
  // Timer period
  const double Complex::State3::ChildState3::timerPeriod = 0.1;
  
  void Complex::State3::ChildState3::initialize ( void ) {
    // if we're a leaf state, make sure we're active
    makeActive();
  }
  
  void Complex::State3::ChildState3::entry ( void ) {
    #ifdef DEBUG_OUTPUT
    std::cout << "ENTRY::Complex::State3::ChildState3::/c/T/w" << std::endl;
    #endif
    // Entry action for this state
    //::::/c/T/w::::Entry::::
    
  }
  
  void Complex::State3::ChildState3::exit ( void ) {
    #ifdef DEBUG_OUTPUT
    std::cout << "EXIT::Complex::State3::ChildState3::/c/T/w" << std::endl;
    #endif
    // Call the Exit Action for this state
    //::::/c/T/w::::Exit::::
    
  }
  
  void Complex::State3::ChildState3::tick ( void ) {
    #ifdef DEBUG_OUTPUT
    std::cout << "TICK::Complex::State3::ChildState3::/c/T/w" << std::endl;
    #endif
    // Call the Tick Action for this state
    //::::/c/T/w::::Tick::::
    
    if ( _activeState != nullptr && _activeState != this )
      _activeState->tick();
  }
  
  double Complex::State3::ChildState3::getTimerPeriod ( void ) {
    return timerPeriod;
  }
  
  bool Complex::State3::ChildState3::handleEvent ( StateMachine::Event* event ) {
    bool handled = false;
  
    // take care of all event types that this branch will not handle -
    // for more consistent run-time performnace
    switch ( event->type() ) {
    case Event::Type::EVENT1:
      handled = true;
      break;
    default:
      break;
    }
  
    if (handled) {
      // we didn't actually handle the event, but return anyway
      return false;
    }
  
    // handle internal transitions first
    switch ( event->type() ) {
    default:
      break;
    }
    if (!handled) {
      // handle external transitions here
      switch ( event->type() ) {
      case Event::Type::EVENT3:
        if ( false ) { }  // makes generation easier :)
        else if ( true ) {
          #ifdef DEBUG_OUTPUT
          std::cout << "NO GUARD on EXTERNAL TRANSITION:/c/T/p" << std::endl;
          #endif
          // Transitioning states!
          // Call all from prev state down exits
        COMPLEX_OBJ__STATE3_OBJ__CHILDSTATE3_OBJ->exitChildren();
        // State : exit for: /c/T/w
        COMPLEX_OBJ__STATE3_OBJ__CHILDSTATE3_OBJ->exit();
        // External Transition : Action for: /c/T/p
        #ifdef DEBUG_OUTPUT
        std::cout << "TRANSITION::ACTION for /c/T/p" << std::endl;
        #endif
        
        //::::/c/T/p::::Action::::
        
        // State : entry for: /c/T/W
        COMPLEX_OBJ__STATE3_OBJ__CHILDSTATE_OBJ->entry();
        #ifdef DEBUG_OUTPUT
        std::cout << "STATE TRANSITION: Complex::State3::ChildState3->Complex::State3::ChildState" << std::endl;
        #endif
        
          // going into regular state
          COMPLEX_OBJ__STATE3_OBJ__CHILDSTATE_OBJ->initialize();
          // make sure nothing else handles this event
          handled = true;
          }
        break;
      default:
        break;
      }
    }
    if (!handled) {
      // now check parent states
      handled = _parentState->handleEvent( event );
    }
    return handled;
  }
};

// Root of the HFSM
StateMachine::Complex *const Complex_root = &StateMachine::COMPLEX_OBJ_stateObj;
// Event Factory
StateMachine::EventFactory EVENT_FACTORY;
StateMachine::EventFactory *const eventFactory = &EVENT_FACTORY;

