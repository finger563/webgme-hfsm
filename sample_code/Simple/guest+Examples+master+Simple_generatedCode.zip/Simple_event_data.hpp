#pragma once

namespace state_machine::Simple {
struct INPUTEVENTEventData {
};

}; // namespace state_machine::Simple
