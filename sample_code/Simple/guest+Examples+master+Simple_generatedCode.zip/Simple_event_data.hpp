#pragma once

#include <string>

namespace espp::state_machine::Simple {

namespace detail {
inline std::string field_to_string(bool v) { return v ? "true" : "false"; }
inline std::string field_to_string(const std::string &v) { return "\"" + v + "\""; }
template <typename T>
inline std::string field_to_string(const T &v) {
  using std::to_string;
  return to_string(v);
}
} // namespace detail

struct INPUTEVENTEventData {
  int button_id{ 12 };
  int press_time_ms{ 100 };
};
inline std::string event_data_to_string(const INPUTEVENTEventData &data) {
  return std::string("{ ") +
    "button_id=" + detail::field_to_string(data.button_id) + ", " +
    "press_time_ms=" + detail::field_to_string(data.press_time_ms) +
    " }";
}
struct TestEventData {
  std::vector val{ {} };
};
inline std::string event_data_to_string(const TestEventData &data) {
  return std::string("{ ") +
    "val=" + detail::field_to_string(data.val) +
    " }";
}

}; // namespace espp::state_machine::Simple
