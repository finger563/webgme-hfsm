#pragma once

namespace state_machine::Complex {
struct ENDEVENTEventData {
};
struct EVENT1EventData {
};
struct EVENT2EventData {
};
struct EVENT3EventData {
};
struct EVENT4EventData {
};

}; // namespace state_machine::Complex
