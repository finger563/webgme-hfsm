#ifndef __GENERATED_STATES_INCLUDE_GUARD__
#define __GENERATED_STATES_INCLUDE_GUARD__

#include "StateBase.hpp"
#include "DeepHistoryState.hpp"
#include "ShallowHistoryState.hpp"

// User Includes for the HFSM
//::::/o::::Includes::::


namespace StateMachine {

  // ROOT OF THE HFSM
  class Medium : public StateMachine::StateBase {
  public:

    // User Declarations for the HFSM
    //::::/o::::Declarations::::
      static bool reInitialize;
  static bool goToShallowHistory;
  static bool goToDeepHistory;
  static bool cycle;

    // Child Substates
    /**
     * @brief Declaration for Medium::State3 : /o/K
     *
     * States contain other states and can consume generic
     * StateMachine::Event objects if they have internal or external
     * transitions on those events and if those transitions' guards are
     * satisfied. Only one transition can consume an event in a given
     * state machine.
     *
     * There is also a different kind of Event, the tick event, which is
     * not consumed, but instead executes from the top-level state all
     * the way to the curently active leaf state.
     *
     * Entry and Exit actions also occur whenever a state is entered or
     * exited, respectively.
     */
    class State3 : public StateMachine::StateBase {
    public:
    
      
      // Timer period
      static const double timerPeriod;
    
      // Constructors
      State3  ( void ) : StateBase( ) {}
      State3  ( StateBase* _parent ) : StateBase( _parent ) {}
      ~State3 ( void ) {}
    
      /**
       * @brief Calls entry() then handles any child
       *  initialization. Finally calls makeActive on the leaf.
       */
      void                     initialize ( void );
        
      /**
       * @brief Runs the entry() function defined in the model.
       */
      void                     entry ( void );
    
      /**
       * @brief Runs the exit() function defined in the model.
       */
      void                     exit ( void );
    
      /**
       * @brief Runs the tick() function defined in the model and then
       *  calls _activeState->tick().
       */
      void                     tick ( void );
    
      /**
       * @brief The timer period of the state in floating point seconds.
       *
       * @return  double  timer period
       */
      double                   getTimerPeriod ( void );
    
      /**
       * @brief Calls _activeState->handleEvent( event ), then if the
       *  event is not nullptr (meaning the event was not consumed by
       *  the child subtree), it checks the event against all internal
       *  transitions associated with that Event.  If the event is still
       *  not a nullptr (meaning the event was not consumed by the
       *  internal transitions), then it checks the event against all
       *  external transitions associated with that Event.
       *
       * @param[in] StateMachine::Event* Event needing to be handled
       *
       * @return true if event is consumed, false otherwise
       */
      bool                     handleEvent ( StateMachine::Event* event );
    };
    /**
     * @brief Declaration for Medium::State4 : /o/q
     *
     * States contain other states and can consume generic
     * StateMachine::Event objects if they have internal or external
     * transitions on those events and if those transitions' guards are
     * satisfied. Only one transition can consume an event in a given
     * state machine.
     *
     * There is also a different kind of Event, the tick event, which is
     * not consumed, but instead executes from the top-level state all
     * the way to the curently active leaf state.
     *
     * Entry and Exit actions also occur whenever a state is entered or
     * exited, respectively.
     */
    class State4 : public StateMachine::StateBase {
    public:
    
      
      // Timer period
      static const double timerPeriod;
    
      // Constructors
      State4  ( void ) : StateBase( ) {}
      State4  ( StateBase* _parent ) : StateBase( _parent ) {}
      ~State4 ( void ) {}
    
      /**
       * @brief Calls entry() then handles any child
       *  initialization. Finally calls makeActive on the leaf.
       */
      void                     initialize ( void );
        
      /**
       * @brief Runs the entry() function defined in the model.
       */
      void                     entry ( void );
    
      /**
       * @brief Runs the exit() function defined in the model.
       */
      void                     exit ( void );
    
      /**
       * @brief Runs the tick() function defined in the model and then
       *  calls _activeState->tick().
       */
      void                     tick ( void );
    
      /**
       * @brief The timer period of the state in floating point seconds.
       *
       * @return  double  timer period
       */
      double                   getTimerPeriod ( void );
    
      /**
       * @brief Calls _activeState->handleEvent( event ), then if the
       *  event is not nullptr (meaning the event was not consumed by
       *  the child subtree), it checks the event against all internal
       *  transitions associated with that Event.  If the event is still
       *  not a nullptr (meaning the event was not consumed by the
       *  internal transitions), then it checks the event against all
       *  external transitions associated with that Event.
       *
       * @param[in] StateMachine::Event* Event needing to be handled
       *
       * @return true if event is consumed, false otherwise
       */
      bool                     handleEvent ( StateMachine::Event* event );
    };
    /**
     * @brief Declaration for Medium::State2 : /o/y
     *
     * States contain other states and can consume generic
     * StateMachine::Event objects if they have internal or external
     * transitions on those events and if those transitions' guards are
     * satisfied. Only one transition can consume an event in a given
     * state machine.
     *
     * There is also a different kind of Event, the tick event, which is
     * not consumed, but instead executes from the top-level state all
     * the way to the curently active leaf state.
     *
     * Entry and Exit actions also occur whenever a state is entered or
     * exited, respectively.
     */
    class State2 : public StateMachine::StateBase {
    public:
    
      
      // Timer period
      static const double timerPeriod;
    
      // Constructors
      State2  ( void ) : StateBase( ) {}
      State2  ( StateBase* _parent ) : StateBase( _parent ) {}
      ~State2 ( void ) {}
    
      /**
       * @brief Calls entry() then handles any child
       *  initialization. Finally calls makeActive on the leaf.
       */
      void                     initialize ( void );
        
      /**
       * @brief Runs the entry() function defined in the model.
       */
      void                     entry ( void );
    
      /**
       * @brief Runs the exit() function defined in the model.
       */
      void                     exit ( void );
    
      /**
       * @brief Runs the tick() function defined in the model and then
       *  calls _activeState->tick().
       */
      void                     tick ( void );
    
      /**
       * @brief The timer period of the state in floating point seconds.
       *
       * @return  double  timer period
       */
      double                   getTimerPeriod ( void );
    
      /**
       * @brief Calls _activeState->handleEvent( event ), then if the
       *  event is not nullptr (meaning the event was not consumed by
       *  the child subtree), it checks the event against all internal
       *  transitions associated with that Event.  If the event is still
       *  not a nullptr (meaning the event was not consumed by the
       *  internal transitions), then it checks the event against all
       *  external transitions associated with that Event.
       *
       * @param[in] StateMachine::Event* Event needing to be handled
       *
       * @return true if event is consumed, false otherwise
       */
      bool                     handleEvent ( StateMachine::Event* event );
    };
    /**
     * @brief Declaration for Medium::State1 : /o/r
     *
     * States contain other states and can consume generic
     * StateMachine::Event objects if they have internal or external
     * transitions on those events and if those transitions' guards are
     * satisfied. Only one transition can consume an event in a given
     * state machine.
     *
     * There is also a different kind of Event, the tick event, which is
     * not consumed, but instead executes from the top-level state all
     * the way to the curently active leaf state.
     *
     * Entry and Exit actions also occur whenever a state is entered or
     * exited, respectively.
     */
    class State1 : public StateMachine::StateBase {
    public:
    
      /**
       * @brief Declaration for Medium::State1::Child2 : /o/r/6
       *
       * States contain other states and can consume generic
       * StateMachine::Event objects if they have internal or external
       * transitions on those events and if those transitions' guards are
       * satisfied. Only one transition can consume an event in a given
       * state machine.
       *
       * There is also a different kind of Event, the tick event, which is
       * not consumed, but instead executes from the top-level state all
       * the way to the curently active leaf state.
       *
       * Entry and Exit actions also occur whenever a state is entered or
       * exited, respectively.
       */
      class Child2 : public StateMachine::StateBase {
      public:
      
        /**
         * @brief Declaration for Medium::State1::Child2::Grand2 : /o/r/6/7
         *
         * States contain other states and can consume generic
         * StateMachine::Event objects if they have internal or external
         * transitions on those events and if those transitions' guards are
         * satisfied. Only one transition can consume an event in a given
         * state machine.
         *
         * There is also a different kind of Event, the tick event, which is
         * not consumed, but instead executes from the top-level state all
         * the way to the curently active leaf state.
         *
         * Entry and Exit actions also occur whenever a state is entered or
         * exited, respectively.
         */
        class Grand2 : public StateMachine::StateBase {
        public:
        
          
          // Timer period
          static const double timerPeriod;
        
          // Constructors
          Grand2  ( void ) : StateBase( ) {}
          Grand2  ( StateBase* _parent ) : StateBase( _parent ) {}
          ~Grand2 ( void ) {}
        
          /**
           * @brief Calls entry() then handles any child
           *  initialization. Finally calls makeActive on the leaf.
           */
          void                     initialize ( void );
            
          /**
           * @brief Runs the entry() function defined in the model.
           */
          void                     entry ( void );
        
          /**
           * @brief Runs the exit() function defined in the model.
           */
          void                     exit ( void );
        
          /**
           * @brief Runs the tick() function defined in the model and then
           *  calls _activeState->tick().
           */
          void                     tick ( void );
        
          /**
           * @brief The timer period of the state in floating point seconds.
           *
           * @return  double  timer period
           */
          double                   getTimerPeriod ( void );
        
          /**
           * @brief Calls _activeState->handleEvent( event ), then if the
           *  event is not nullptr (meaning the event was not consumed by
           *  the child subtree), it checks the event against all internal
           *  transitions associated with that Event.  If the event is still
           *  not a nullptr (meaning the event was not consumed by the
           *  internal transitions), then it checks the event against all
           *  external transitions associated with that Event.
           *
           * @param[in] StateMachine::Event* Event needing to be handled
           *
           * @return true if event is consumed, false otherwise
           */
          bool                     handleEvent ( StateMachine::Event* event );
        };
        /**
         * @brief Declaration for Medium::State1::Child2::Grand : /o/r/6/w
         *
         * States contain other states and can consume generic
         * StateMachine::Event objects if they have internal or external
         * transitions on those events and if those transitions' guards are
         * satisfied. Only one transition can consume an event in a given
         * state machine.
         *
         * There is also a different kind of Event, the tick event, which is
         * not consumed, but instead executes from the top-level state all
         * the way to the curently active leaf state.
         *
         * Entry and Exit actions also occur whenever a state is entered or
         * exited, respectively.
         */
        class Grand : public StateMachine::StateBase {
        public:
        
          
          // Timer period
          static const double timerPeriod;
        
          // Constructors
          Grand  ( void ) : StateBase( ) {}
          Grand  ( StateBase* _parent ) : StateBase( _parent ) {}
          ~Grand ( void ) {}
        
          /**
           * @brief Calls entry() then handles any child
           *  initialization. Finally calls makeActive on the leaf.
           */
          void                     initialize ( void );
            
          /**
           * @brief Runs the entry() function defined in the model.
           */
          void                     entry ( void );
        
          /**
           * @brief Runs the exit() function defined in the model.
           */
          void                     exit ( void );
        
          /**
           * @brief Runs the tick() function defined in the model and then
           *  calls _activeState->tick().
           */
          void                     tick ( void );
        
          /**
           * @brief The timer period of the state in floating point seconds.
           *
           * @return  double  timer period
           */
          double                   getTimerPeriod ( void );
        
          /**
           * @brief Calls _activeState->handleEvent( event ), then if the
           *  event is not nullptr (meaning the event was not consumed by
           *  the child subtree), it checks the event against all internal
           *  transitions associated with that Event.  If the event is still
           *  not a nullptr (meaning the event was not consumed by the
           *  internal transitions), then it checks the event against all
           *  external transitions associated with that Event.
           *
           * @param[in] StateMachine::Event* Event needing to be handled
           *
           * @return true if event is consumed, false otherwise
           */
          bool                     handleEvent ( StateMachine::Event* event );
        };
        
        // Timer period
        static const double timerPeriod;
      
        // Constructors
        Child2  ( void ) : StateBase( ) {}
        Child2  ( StateBase* _parent ) : StateBase( _parent ) {}
        ~Child2 ( void ) {}
      
        /**
         * @brief Calls entry() then handles any child
         *  initialization. Finally calls makeActive on the leaf.
         */
        void                     initialize ( void );
          
        /**
         * @brief Runs the entry() function defined in the model.
         */
        void                     entry ( void );
      
        /**
         * @brief Runs the exit() function defined in the model.
         */
        void                     exit ( void );
      
        /**
         * @brief Runs the tick() function defined in the model and then
         *  calls _activeState->tick().
         */
        void                     tick ( void );
      
        /**
         * @brief The timer period of the state in floating point seconds.
         *
         * @return  double  timer period
         */
        double                   getTimerPeriod ( void );
      
        /**
         * @brief Calls _activeState->handleEvent( event ), then if the
         *  event is not nullptr (meaning the event was not consumed by
         *  the child subtree), it checks the event against all internal
         *  transitions associated with that Event.  If the event is still
         *  not a nullptr (meaning the event was not consumed by the
         *  internal transitions), then it checks the event against all
         *  external transitions associated with that Event.
         *
         * @param[in] StateMachine::Event* Event needing to be handled
         *
         * @return true if event is consumed, false otherwise
         */
        bool                     handleEvent ( StateMachine::Event* event );
      };
      /**
       * @brief Declaration for Medium::State1::Child3 : /o/r/P
       *
       * States contain other states and can consume generic
       * StateMachine::Event objects if they have internal or external
       * transitions on those events and if those transitions' guards are
       * satisfied. Only one transition can consume an event in a given
       * state machine.
       *
       * There is also a different kind of Event, the tick event, which is
       * not consumed, but instead executes from the top-level state all
       * the way to the curently active leaf state.
       *
       * Entry and Exit actions also occur whenever a state is entered or
       * exited, respectively.
       */
      class Child3 : public StateMachine::StateBase {
      public:
      
        
        // Timer period
        static const double timerPeriod;
      
        // Constructors
        Child3  ( void ) : StateBase( ) {}
        Child3  ( StateBase* _parent ) : StateBase( _parent ) {}
        ~Child3 ( void ) {}
      
        /**
         * @brief Calls entry() then handles any child
         *  initialization. Finally calls makeActive on the leaf.
         */
        void                     initialize ( void );
          
        /**
         * @brief Runs the entry() function defined in the model.
         */
        void                     entry ( void );
      
        /**
         * @brief Runs the exit() function defined in the model.
         */
        void                     exit ( void );
      
        /**
         * @brief Runs the tick() function defined in the model and then
         *  calls _activeState->tick().
         */
        void                     tick ( void );
      
        /**
         * @brief The timer period of the state in floating point seconds.
         *
         * @return  double  timer period
         */
        double                   getTimerPeriod ( void );
      
        /**
         * @brief Calls _activeState->handleEvent( event ), then if the
         *  event is not nullptr (meaning the event was not consumed by
         *  the child subtree), it checks the event against all internal
         *  transitions associated with that Event.  If the event is still
         *  not a nullptr (meaning the event was not consumed by the
         *  internal transitions), then it checks the event against all
         *  external transitions associated with that Event.
         *
         * @param[in] StateMachine::Event* Event needing to be handled
         *
         * @return true if event is consumed, false otherwise
         */
        bool                     handleEvent ( StateMachine::Event* event );
      };
      /**
       * @brief Declaration for Medium::State1::Child1 : /o/r/L
       *
       * States contain other states and can consume generic
       * StateMachine::Event objects if they have internal or external
       * transitions on those events and if those transitions' guards are
       * satisfied. Only one transition can consume an event in a given
       * state machine.
       *
       * There is also a different kind of Event, the tick event, which is
       * not consumed, but instead executes from the top-level state all
       * the way to the curently active leaf state.
       *
       * Entry and Exit actions also occur whenever a state is entered or
       * exited, respectively.
       */
      class Child1 : public StateMachine::StateBase {
      public:
      
        
        // Timer period
        static const double timerPeriod;
      
        // Constructors
        Child1  ( void ) : StateBase( ) {}
        Child1  ( StateBase* _parent ) : StateBase( _parent ) {}
        ~Child1 ( void ) {}
      
        /**
         * @brief Calls entry() then handles any child
         *  initialization. Finally calls makeActive on the leaf.
         */
        void                     initialize ( void );
          
        /**
         * @brief Runs the entry() function defined in the model.
         */
        void                     entry ( void );
      
        /**
         * @brief Runs the exit() function defined in the model.
         */
        void                     exit ( void );
      
        /**
         * @brief Runs the tick() function defined in the model and then
         *  calls _activeState->tick().
         */
        void                     tick ( void );
      
        /**
         * @brief The timer period of the state in floating point seconds.
         *
         * @return  double  timer period
         */
        double                   getTimerPeriod ( void );
      
        /**
         * @brief Calls _activeState->handleEvent( event ), then if the
         *  event is not nullptr (meaning the event was not consumed by
         *  the child subtree), it checks the event against all internal
         *  transitions associated with that Event.  If the event is still
         *  not a nullptr (meaning the event was not consumed by the
         *  internal transitions), then it checks the event against all
         *  external transitions associated with that Event.
         *
         * @param[in] StateMachine::Event* Event needing to be handled
         *
         * @return true if event is consumed, false otherwise
         */
        bool                     handleEvent ( StateMachine::Event* event );
      };
      
      // Timer period
      static const double timerPeriod;
    
      // Constructors
      State1  ( void ) : StateBase( ) {}
      State1  ( StateBase* _parent ) : StateBase( _parent ) {}
      ~State1 ( void ) {}
    
      /**
       * @brief Calls entry() then handles any child
       *  initialization. Finally calls makeActive on the leaf.
       */
      void                     initialize ( void );
        
      /**
       * @brief Runs the entry() function defined in the model.
       */
      void                     entry ( void );
    
      /**
       * @brief Runs the exit() function defined in the model.
       */
      void                     exit ( void );
    
      /**
       * @brief Runs the tick() function defined in the model and then
       *  calls _activeState->tick().
       */
      void                     tick ( void );
    
      /**
       * @brief The timer period of the state in floating point seconds.
       *
       * @return  double  timer period
       */
      double                   getTimerPeriod ( void );
    
      /**
       * @brief Calls _activeState->handleEvent( event ), then if the
       *  event is not nullptr (meaning the event was not consumed by
       *  the child subtree), it checks the event against all internal
       *  transitions associated with that Event.  If the event is still
       *  not a nullptr (meaning the event was not consumed by the
       *  internal transitions), then it checks the event against all
       *  external transitions associated with that Event.
       *
       * @param[in] StateMachine::Event* Event needing to be handled
       *
       * @return true if event is consumed, false otherwise
       */
      bool                     handleEvent ( StateMachine::Event* event );
    };
    // END STATE
    /**
     * @brief This is the terminal END STATE for the HFSM, after which no
     *  events or other actions will be processed.
     */
    class End_State : public StateMachine::StateBase {
    public:
      
      /**
       * @brief Empty function for the END STATE.
       */
      void entry ( void ) {}
    
      /**
       * @brief Empty function for the END STATE.
       */
      void exit ( void ) {}
    
      /**
       * @brief Empty function for the END STATE.
       */
      void tick ( void ) {}
    
      /**
       * @brief Empty function for the END STATE. Simply returns true
       *  since the END STATE trivially handles all events.
       *
       * @return true 
       */
      bool handleEvent ( StateMachine::Event* event ) { return true; }
    };

    // Constructors
    Medium  ( void ) : StateBase( ) {}
    Medium  ( StateBase* _parent ) : StateBase( _parent ) {}
    ~Medium ( void ) {}
    
    /**
     * @brief Fully initializes the HFSM. Runs the HFSM Initialization
     *  code from the model, then sets the inital state and runs the
     *  initial transition and entry actions accordingly.
     */
    void                     initialize ( void );
    
    /**
     * @brief Terminates the HFSM, calling exit functions for the
     *  active leaf state upwards through its parents all the way to
     *  the root.
     */
    void                     terminate  ( void );

    /**
     * @brief Restarts the HFSM by calling terminate and then
     *  initialize.
     */
    void                     restart    ( void );

    /**
     * @brief Returns true if the HFSM has reached its END State
     */
    bool                     hasStopped ( void );

    /**
     * @brief Calls handleEvent on the activeLeaf.
     *
     * @param[in] StateMachine::Event* Event needing to be handled
     *
     * @return true if event is consumed, false otherwise
     */
    bool                     handleEvent ( StateMachine::Event* event );
  };
};

// pointers
extern StateMachine::Medium *const Medium_root;
extern StateMachine::Medium *const MEDIUM_OBJ;
extern StateMachine::Medium::State3 *const MEDIUM_OBJ__STATE3_OBJ;
extern StateMachine::Medium::State4 *const MEDIUM_OBJ__STATE4_OBJ;
extern StateMachine::Medium::State2 *const MEDIUM_OBJ__STATE2_OBJ;
extern StateMachine::Medium::State1 *const MEDIUM_OBJ__STATE1_OBJ;
extern StateMachine::Medium::State1::Child2 *const MEDIUM_OBJ__STATE1_OBJ__CHILD2_OBJ;
extern StateMachine::Medium::State1::Child2::Grand2 *const MEDIUM_OBJ__STATE1_OBJ__CHILD2_OBJ__GRAND2_OBJ;
extern StateMachine::Medium::State1::Child2::Grand *const MEDIUM_OBJ__STATE1_OBJ__CHILD2_OBJ__GRAND_OBJ;
extern StateMachine::ShallowHistoryState *const MEDIUM_OBJ__STATE1_OBJ__SHALLOW_HISTORY_PSEUDOSTATE_OBJ;
extern StateMachine::Medium::State1::Child3 *const MEDIUM_OBJ__STATE1_OBJ__CHILD3_OBJ;
extern StateMachine::Medium::State1::Child1 *const MEDIUM_OBJ__STATE1_OBJ__CHILD1_OBJ;
extern StateMachine::DeepHistoryState *const MEDIUM_OBJ__STATE1_OBJ__DEEP_HISTORY_PSEUDOSTATE_OBJ;
extern StateMachine::StateBase *const MEDIUM_OBJ__END_STATE_OBJ;
#endif // __GENERATED_STATES_INCLUDE_GUARD__
