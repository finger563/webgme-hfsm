#include "Medium_Events.hpp"
#include "Medium_GeneratedStates.hpp"

#ifdef DEBUG_OUTPUT
#include <iostream>
#endif

namespace StateMachine {
  StateMachine::Medium        MEDIUM_OBJ_stateObj;
  StateMachine::Medium *const MEDIUM_OBJ = &MEDIUM_OBJ_stateObj;
  StateMachine::Medium::State3        MEDIUM_OBJ__STATE3_OBJ_stateObj( MEDIUM_OBJ );
  StateMachine::Medium::State3 *const MEDIUM_OBJ__STATE3_OBJ = &MEDIUM_OBJ__STATE3_OBJ_stateObj;
  
  StateMachine::Medium::State4        MEDIUM_OBJ__STATE4_OBJ_stateObj( MEDIUM_OBJ );
  StateMachine::Medium::State4 *const MEDIUM_OBJ__STATE4_OBJ = &MEDIUM_OBJ__STATE4_OBJ_stateObj;
  
  StateMachine::Medium::State2        MEDIUM_OBJ__STATE2_OBJ_stateObj( MEDIUM_OBJ );
  StateMachine::Medium::State2 *const MEDIUM_OBJ__STATE2_OBJ = &MEDIUM_OBJ__STATE2_OBJ_stateObj;
  
  StateMachine::Medium::State1        MEDIUM_OBJ__STATE1_OBJ_stateObj( MEDIUM_OBJ );
  StateMachine::Medium::State1 *const MEDIUM_OBJ__STATE1_OBJ = &MEDIUM_OBJ__STATE1_OBJ_stateObj;
  StateMachine::Medium::State1::Child2        MEDIUM_OBJ__STATE1_OBJ__CHILD2_OBJ_stateObj( MEDIUM_OBJ__STATE1_OBJ );
  StateMachine::Medium::State1::Child2 *const MEDIUM_OBJ__STATE1_OBJ__CHILD2_OBJ = &MEDIUM_OBJ__STATE1_OBJ__CHILD2_OBJ_stateObj;
  StateMachine::Medium::State1::Child2::Grand2        MEDIUM_OBJ__STATE1_OBJ__CHILD2_OBJ__GRAND2_OBJ_stateObj( MEDIUM_OBJ__STATE1_OBJ__CHILD2_OBJ );
  StateMachine::Medium::State1::Child2::Grand2 *const MEDIUM_OBJ__STATE1_OBJ__CHILD2_OBJ__GRAND2_OBJ = &MEDIUM_OBJ__STATE1_OBJ__CHILD2_OBJ__GRAND2_OBJ_stateObj;
  
  StateMachine::Medium::State1::Child2::Grand        MEDIUM_OBJ__STATE1_OBJ__CHILD2_OBJ__GRAND_OBJ_stateObj( MEDIUM_OBJ__STATE1_OBJ__CHILD2_OBJ );
  StateMachine::Medium::State1::Child2::Grand *const MEDIUM_OBJ__STATE1_OBJ__CHILD2_OBJ__GRAND_OBJ = &MEDIUM_OBJ__STATE1_OBJ__CHILD2_OBJ__GRAND_OBJ_stateObj;
  
  
  
  StateMachine::ShallowHistoryState        MEDIUM_OBJ__STATE1_OBJ__SHALLOW_HISTORY_PSEUDOSTATE_OBJ_stateObj( MEDIUM_OBJ__STATE1_OBJ );
  StateMachine::ShallowHistoryState *const MEDIUM_OBJ__STATE1_OBJ__SHALLOW_HISTORY_PSEUDOSTATE_OBJ = &MEDIUM_OBJ__STATE1_OBJ__SHALLOW_HISTORY_PSEUDOSTATE_OBJ_stateObj;
  
  StateMachine::Medium::State1::Child3        MEDIUM_OBJ__STATE1_OBJ__CHILD3_OBJ_stateObj( MEDIUM_OBJ__STATE1_OBJ );
  StateMachine::Medium::State1::Child3 *const MEDIUM_OBJ__STATE1_OBJ__CHILD3_OBJ = &MEDIUM_OBJ__STATE1_OBJ__CHILD3_OBJ_stateObj;
  
  StateMachine::Medium::State1::Child1        MEDIUM_OBJ__STATE1_OBJ__CHILD1_OBJ_stateObj( MEDIUM_OBJ__STATE1_OBJ );
  StateMachine::Medium::State1::Child1 *const MEDIUM_OBJ__STATE1_OBJ__CHILD1_OBJ = &MEDIUM_OBJ__STATE1_OBJ__CHILD1_OBJ_stateObj;
  
  StateMachine::DeepHistoryState           MEDIUM_OBJ__STATE1_OBJ__DEEP_HISTORY_PSEUDOSTATE_OBJ_stateObj( MEDIUM_OBJ__STATE1_OBJ );
  StateMachine::DeepHistoryState    *const MEDIUM_OBJ__STATE1_OBJ__DEEP_HISTORY_PSEUDOSTATE_OBJ = &MEDIUM_OBJ__STATE1_OBJ__DEEP_HISTORY_PSEUDOSTATE_OBJ_stateObj;
  
  
  
  
  StateMachine::StateBase         MEDIUM_OBJ__END_STATE_OBJ_stateObj( MEDIUM_OBJ );
  StateMachine::StateBase *const  MEDIUM_OBJ__END_STATE_OBJ = &MEDIUM_OBJ__END_STATE_OBJ_stateObj;
  // User Definitions for the HFSM
  //::::/o::::Definitions::::
    bool Medium::reInitialize       = false;
  bool Medium::goToShallowHistory = false;
  bool Medium::goToDeepHistory    = true;
  bool Medium::cycle              = true;

  /* * *  Definitions for Medium : /o  * * */
  // Generated Definitions for the root state
  void Medium::initialize ( void ) {
    // Run the model's Initialization code
    #ifdef DEBUG_OUTPUT
    std::cout << "Medium:/o HFSM Initialization" << std::endl;
    #endif
    //::::/o::::Initialization::::
    
    // now set the states up properly
    // External Transition : Action for: /o/E
    #ifdef DEBUG_OUTPUT
    std::cout << "TRANSITION::ACTION for /o/E" << std::endl;
    #endif
    
    //::::/o/E::::Action::::
    
    // State : entry for: /o/r
    MEDIUM_OBJ__STATE1_OBJ->entry();
    
    // initialize our new active state
    MEDIUM_OBJ__STATE1_OBJ->initialize();
  };
  
  void Medium::terminate ( void ) {
    // will call exit() and exitChildren() on _activeState if it
    // exists
    exitChildren();
  };
  
  void Medium::restart ( void ) {
    terminate();
    initialize();
  };
  
  bool Medium::hasStopped ( void ) {
    bool reachedEnd = false;
    // Get the currently active leaf state
    StateMachine::StateBase* activeLeaf = getActiveLeaf();
    if (activeLeaf != nullptr && activeLeaf != this && activeLeaf == MEDIUM_OBJ__END_STATE_OBJ) {
      reachedEnd = true;
    }
    return reachedEnd;
  };
  
  bool Medium::handleEvent ( StateMachine::Event* event ) {
    bool handled = false;

    // Get the currently active leaf state
    StateMachine::StateBase* activeLeaf = getActiveLeaf();

    if (activeLeaf != nullptr && activeLeaf != this) {
      // have the active leaf handle the event, this will bubble up until
      // the event is handled or it reaches the root.
      handled = activeLeaf->handleEvent( event );
    }

    return handled;
  }
  /* * *  Definitions for Medium::State3 : /o/K  * * */
  // Timer period
  const double Medium::State3::timerPeriod = 0.1;
  
  void Medium::State3::initialize ( void ) {
    // if we're a leaf state, make sure we're active
    makeActive();
  }
  
  void Medium::State3::entry ( void ) {
    #ifdef DEBUG_OUTPUT
    std::cout << "ENTRY::Medium::State3::/o/K" << std::endl;
    #endif
    // Entry action for this state
    //::::/o/K::::Entry::::
    
  }
  
  void Medium::State3::exit ( void ) {
    #ifdef DEBUG_OUTPUT
    std::cout << "EXIT::Medium::State3::/o/K" << std::endl;
    #endif
    // Call the Exit Action for this state
    //::::/o/K::::Exit::::
    
  }
  
  void Medium::State3::tick ( void ) {
    #ifdef DEBUG_OUTPUT
    std::cout << "TICK::Medium::State3::/o/K" << std::endl;
    #endif
    // Call the Tick Action for this state
    //::::/o/K::::Tick::::
    
    if ( _activeState != nullptr && _activeState != this )
      _activeState->tick();
  }
  
  double Medium::State3::getTimerPeriod ( void ) {
    return timerPeriod;
  }
  
  bool Medium::State3::handleEvent ( StateMachine::Event* event ) {
    bool handled = false;
  
    // take care of all event types that this branch will not handle -
    // for more consistent run-time performnace
    switch ( event->type() ) {
    case Event::Type::EVENT1:
      handled = true;
      break;
    case Event::Type::EVENT2:
      handled = true;
      break;
    case Event::Type::EVENT4:
      handled = true;
      break;
    default:
      break;
    }
  
    if (handled) {
      // we didn't actually handle the event, but return anyway
      return false;
    }
  
    // handle internal transitions first
    switch ( event->type() ) {
    default:
      break;
    }
    if (!handled) {
      // handle external transitions here
      switch ( event->type() ) {
      case Event::Type::EVENT3:
        if ( false ) { }  // makes generation easier :)
        else if ( true ) {
          #ifdef DEBUG_OUTPUT
          std::cout << "NO GUARD on EXTERNAL TRANSITION:/o/g" << std::endl;
          #endif
          // Transitioning states!
          // Call all from prev state down exits
        MEDIUM_OBJ__STATE3_OBJ->exitChildren();
        // State : exit for: /o/K
        MEDIUM_OBJ__STATE3_OBJ->exit();
        // External Transition : Action for: /o/g
        #ifdef DEBUG_OUTPUT
        std::cout << "TRANSITION::ACTION for /o/g" << std::endl;
        #endif
        
        //::::/o/g::::Action::::
        
        // State : entry for: /o/q
        MEDIUM_OBJ__STATE4_OBJ->entry();
        #ifdef DEBUG_OUTPUT
        std::cout << "STATE TRANSITION: Medium::State3->Medium::State4" << std::endl;
        #endif
        
          // going into regular state
          MEDIUM_OBJ__STATE4_OBJ->initialize();
          // make sure nothing else handles this event
          handled = true;
          }
        break;
      default:
        break;
      }
    }
    // can't buble up, we are a root state.
    return handled;
  }
  /* * *  Definitions for Medium::State4 : /o/q  * * */
  // Timer period
  const double Medium::State4::timerPeriod = 0.1;
  
  void Medium::State4::initialize ( void ) {
    // if we're a leaf state, make sure we're active
    makeActive();
  }
  
  void Medium::State4::entry ( void ) {
    #ifdef DEBUG_OUTPUT
    std::cout << "ENTRY::Medium::State4::/o/q" << std::endl;
    #endif
    // Entry action for this state
    //::::/o/q::::Entry::::
    
  }
  
  void Medium::State4::exit ( void ) {
    #ifdef DEBUG_OUTPUT
    std::cout << "EXIT::Medium::State4::/o/q" << std::endl;
    #endif
    // Call the Exit Action for this state
    //::::/o/q::::Exit::::
    
  }
  
  void Medium::State4::tick ( void ) {
    #ifdef DEBUG_OUTPUT
    std::cout << "TICK::Medium::State4::/o/q" << std::endl;
    #endif
    // Call the Tick Action for this state
    //::::/o/q::::Tick::::
    
    if ( _activeState != nullptr && _activeState != this )
      _activeState->tick();
  }
  
  double Medium::State4::getTimerPeriod ( void ) {
    return timerPeriod;
  }
  
  bool Medium::State4::handleEvent ( StateMachine::Event* event ) {
    bool handled = false;
  
    // take care of all event types that this branch will not handle -
    // for more consistent run-time performnace
    switch ( event->type() ) {
    case Event::Type::EVENT1:
      handled = true;
      break;
    case Event::Type::EVENT2:
      handled = true;
      break;
    case Event::Type::EVENT3:
      handled = true;
      break;
    default:
      break;
    }
  
    if (handled) {
      // we didn't actually handle the event, but return anyway
      return false;
    }
  
    // handle internal transitions first
    switch ( event->type() ) {
    default:
      break;
    }
    if (!handled) {
      // handle external transitions here
      switch ( event->type() ) {
      case Event::Type::EVENT4:
        if ( false ) { }  // makes generation easier :)
        else if ( true ) {
          #ifdef DEBUG_OUTPUT
          std::cout << "NO GUARD on EXTERNAL TRANSITION:/o/x" << std::endl;
          #endif
          // Going into a choice pseudo-state, let it handle its
          // guards and perform the state transition
          if (false) { } // makes geneeration easier :)
          //::::/o/6::::Guard::::
          else if ( goToShallowHistory ) {
            #ifdef DEBUG_OUTPUT
            std::cout << "GUARD [ goToShallowHistory ] for EXTERNAL TRANSITION:/o/6 evaluated to TRUE" << std::endl;
            #endif
            // Transitioning states!
            // Call all from prev state down exits
          MEDIUM_OBJ__STATE4_OBJ->exitChildren();
          // State : exit for: /o/q
          MEDIUM_OBJ__STATE4_OBJ->exit();
          // External Transition : Action for: /o/x
          #ifdef DEBUG_OUTPUT
          std::cout << "TRANSITION::ACTION for /o/x" << std::endl;
          #endif
          
          //::::/o/x::::Action::::
          
          // External Transition : Action for: /o/6
          #ifdef DEBUG_OUTPUT
          std::cout << "TRANSITION::ACTION for /o/6" << std::endl;
          #endif
          
          //::::/o/6::::Action::::
          
          // State : entry for: /o/r
          MEDIUM_OBJ__STATE1_OBJ->entry();
          #ifdef DEBUG_OUTPUT
          std::cout << "STATE TRANSITION: Medium::State4->Medium::State1::Shallow_History_Pseudostate" << std::endl;
          #endif
          
            // going into shallow history pseudo-state
            MEDIUM_OBJ__STATE1_OBJ->setShallowHistory();
              // make sure nothing else handles this event
            handled = true;
            }
          //::::/o/D::::Guard::::
          else if ( reInitialize ) {
            #ifdef DEBUG_OUTPUT
            std::cout << "GUARD [ reInitialize ] for EXTERNAL TRANSITION:/o/D evaluated to TRUE" << std::endl;
            #endif
            // Transitioning states!
            // Call all from prev state down exits
          MEDIUM_OBJ__STATE4_OBJ->exitChildren();
          // State : exit for: /o/q
          MEDIUM_OBJ__STATE4_OBJ->exit();
          // External Transition : Action for: /o/x
          #ifdef DEBUG_OUTPUT
          std::cout << "TRANSITION::ACTION for /o/x" << std::endl;
          #endif
          
          //::::/o/x::::Action::::
          
          // External Transition : Action for: /o/D
          #ifdef DEBUG_OUTPUT
          std::cout << "TRANSITION::ACTION for /o/D" << std::endl;
          #endif
          
          //::::/o/D::::Action::::
          
          // State : entry for: /o/r
          MEDIUM_OBJ__STATE1_OBJ->entry();
          #ifdef DEBUG_OUTPUT
          std::cout << "STATE TRANSITION: Medium::State4->Medium::State1" << std::endl;
          #endif
          
            // going into regular state
            MEDIUM_OBJ__STATE1_OBJ->initialize();
            // make sure nothing else handles this event
            handled = true;
            }
          //::::/o/P::::Guard::::
          else if ( goToDeepHistory ) {
            #ifdef DEBUG_OUTPUT
            std::cout << "GUARD [ goToDeepHistory ] for EXTERNAL TRANSITION:/o/P evaluated to TRUE" << std::endl;
            #endif
            // Transitioning states!
            // Call all from prev state down exits
          MEDIUM_OBJ__STATE4_OBJ->exitChildren();
          // State : exit for: /o/q
          MEDIUM_OBJ__STATE4_OBJ->exit();
          // External Transition : Action for: /o/x
          #ifdef DEBUG_OUTPUT
          std::cout << "TRANSITION::ACTION for /o/x" << std::endl;
          #endif
          
          //::::/o/x::::Action::::
          
          // External Transition : Action for: /o/P
          #ifdef DEBUG_OUTPUT
          std::cout << "TRANSITION::ACTION for /o/P" << std::endl;
          #endif
          
          //::::/o/P::::Action::::
          
          // State : entry for: /o/r
          MEDIUM_OBJ__STATE1_OBJ->entry();
          #ifdef DEBUG_OUTPUT
          std::cout << "STATE TRANSITION: Medium::State4->Medium::State1::Deep_History_Pseudostate" << std::endl;
          #endif
          
            // going into deep history pseudo-state
            MEDIUM_OBJ__STATE1_OBJ->setDeepHistory();
            // make sure nothing else handles this event
            handled = true;
            }
          else if ( true ) {
            #ifdef DEBUG_OUTPUT
            std::cout << "NO GUARD on EXTERNAL TRANSITION:/o/c" << std::endl;
            #endif
            // Transitioning states!
            // Call all from prev state down exits
          MEDIUM_OBJ__STATE4_OBJ->exitChildren();
          // State : exit for: /o/q
          MEDIUM_OBJ__STATE4_OBJ->exit();
          // External Transition : Action for: /o/x
          #ifdef DEBUG_OUTPUT
          std::cout << "TRANSITION::ACTION for /o/x" << std::endl;
          #endif
          
          //::::/o/x::::Action::::
          
          // External Transition : Action for: /o/c
          #ifdef DEBUG_OUTPUT
          std::cout << "TRANSITION::ACTION for /o/c" << std::endl;
          #endif
          
          //::::/o/c::::Action::::
          
          #ifdef DEBUG_OUTPUT
          std::cout << "STATE TRANSITION: Medium::State4->Medium::End_State" << std::endl;
          #endif
          
            // going into end pseudo-state THIS SHOULD BE TOP LEVEL END STATE
            MEDIUM_OBJ__END_STATE_OBJ->makeActive();
            // make sure nothing else handles this event
            handled = true;
            }
        }
        break;
      default:
        break;
      }
    }
    // can't buble up, we are a root state.
    return handled;
  }
  /* * *  Definitions for Medium::State2 : /o/y  * * */
  // Timer period
  const double Medium::State2::timerPeriod = 0.1;
  
  void Medium::State2::initialize ( void ) {
    // if we're a leaf state, make sure we're active
    makeActive();
  }
  
  void Medium::State2::entry ( void ) {
    #ifdef DEBUG_OUTPUT
    std::cout << "ENTRY::Medium::State2::/o/y" << std::endl;
    #endif
    // Entry action for this state
    //::::/o/y::::Entry::::
    
  }
  
  void Medium::State2::exit ( void ) {
    #ifdef DEBUG_OUTPUT
    std::cout << "EXIT::Medium::State2::/o/y" << std::endl;
    #endif
    // Call the Exit Action for this state
    //::::/o/y::::Exit::::
    
  }
  
  void Medium::State2::tick ( void ) {
    #ifdef DEBUG_OUTPUT
    std::cout << "TICK::Medium::State2::/o/y" << std::endl;
    #endif
    // Call the Tick Action for this state
    //::::/o/y::::Tick::::
    
    if ( _activeState != nullptr && _activeState != this )
      _activeState->tick();
  }
  
  double Medium::State2::getTimerPeriod ( void ) {
    return timerPeriod;
  }
  
  bool Medium::State2::handleEvent ( StateMachine::Event* event ) {
    bool handled = false;
  
    // take care of all event types that this branch will not handle -
    // for more consistent run-time performnace
    switch ( event->type() ) {
    case Event::Type::EVENT1:
      handled = true;
      break;
    case Event::Type::EVENT3:
      handled = true;
      break;
    case Event::Type::EVENT4:
      handled = true;
      break;
    default:
      break;
    }
  
    if (handled) {
      // we didn't actually handle the event, but return anyway
      return false;
    }
  
    // handle internal transitions first
    switch ( event->type() ) {
    default:
      break;
    }
    if (!handled) {
      // handle external transitions here
      switch ( event->type() ) {
      case Event::Type::EVENT2:
        if ( false ) { }  // makes generation easier :)
        else if ( true ) {
          #ifdef DEBUG_OUTPUT
          std::cout << "NO GUARD on EXTERNAL TRANSITION:/o/z" << std::endl;
          #endif
          // Transitioning states!
          // Call all from prev state down exits
        MEDIUM_OBJ__STATE2_OBJ->exitChildren();
        // State : exit for: /o/y
        MEDIUM_OBJ__STATE2_OBJ->exit();
        // External Transition : Action for: /o/z
        #ifdef DEBUG_OUTPUT
        std::cout << "TRANSITION::ACTION for /o/z" << std::endl;
        #endif
        
        //::::/o/z::::Action::::
        
        // State : entry for: /o/K
        MEDIUM_OBJ__STATE3_OBJ->entry();
        #ifdef DEBUG_OUTPUT
        std::cout << "STATE TRANSITION: Medium::State2->Medium::State3" << std::endl;
        #endif
        
          // going into regular state
          MEDIUM_OBJ__STATE3_OBJ->initialize();
          // make sure nothing else handles this event
          handled = true;
          }
        break;
      default:
        break;
      }
    }
    // can't buble up, we are a root state.
    return handled;
  }
  /* * *  Definitions for Medium::State1 : /o/r  * * */
  // Timer period
  const double Medium::State1::timerPeriod = 0;
  
  void Medium::State1::initialize ( void ) {
    // External Transition : Action for: /o/r/r
    #ifdef DEBUG_OUTPUT
    std::cout << "TRANSITION::ACTION for /o/r/r" << std::endl;
    #endif
    
    //::::/o/r/r::::Action::::
    
    // State : entry for: /o/r/L
    MEDIUM_OBJ__STATE1_OBJ__CHILD1_OBJ->entry();
    
    // initialize our new active state
    MEDIUM_OBJ__STATE1_OBJ__CHILD1_OBJ->initialize();
  }
  
  void Medium::State1::entry ( void ) {
    #ifdef DEBUG_OUTPUT
    std::cout << "ENTRY::Medium::State1::/o/r" << std::endl;
    #endif
    // Entry action for this state
    //::::/o/r::::Entry::::
    
  }
  
  void Medium::State1::exit ( void ) {
    #ifdef DEBUG_OUTPUT
    std::cout << "EXIT::Medium::State1::/o/r" << std::endl;
    #endif
    // Call the Exit Action for this state
    //::::/o/r::::Exit::::
    
  }
  
  void Medium::State1::tick ( void ) {
    #ifdef DEBUG_OUTPUT
    std::cout << "TICK::Medium::State1::/o/r" << std::endl;
    #endif
    // Call the Tick Action for this state
    //::::/o/r::::Tick::::
    
    if ( _activeState != nullptr && _activeState != this )
      _activeState->tick();
  }
  
  double Medium::State1::getTimerPeriod ( void ) {
    return timerPeriod;
  }
  
  bool Medium::State1::handleEvent ( StateMachine::Event* event ) {
    bool handled = false;
  
    // take care of all event types that this branch will not handle -
    // for more consistent run-time performnace
    switch ( event->type() ) {
    case Event::Type::EVENT2:
      handled = true;
      break;
    case Event::Type::EVENT3:
      handled = true;
      break;
    case Event::Type::EVENT4:
      handled = true;
      break;
    default:
      break;
    }
  
    if (handled) {
      // we didn't actually handle the event, but return anyway
      return false;
    }
  
    // handle internal transitions first
    switch ( event->type() ) {
    default:
      break;
    }
    if (!handled) {
      // handle external transitions here
      switch ( event->type() ) {
      case Event::Type::EVENT1:
        if ( false ) { }  // makes generation easier :)
        else if ( true ) {
          #ifdef DEBUG_OUTPUT
          std::cout << "NO GUARD on EXTERNAL TRANSITION:/o/M" << std::endl;
          #endif
          // Transitioning states!
          // Call all from prev state down exits
        MEDIUM_OBJ__STATE1_OBJ->exitChildren();
        // State : exit for: /o/r
        MEDIUM_OBJ__STATE1_OBJ->exit();
        // External Transition : Action for: /o/M
        #ifdef DEBUG_OUTPUT
        std::cout << "TRANSITION::ACTION for /o/M" << std::endl;
        #endif
        
        //::::/o/M::::Action::::
        
        // State : entry for: /o/y
        MEDIUM_OBJ__STATE2_OBJ->entry();
        #ifdef DEBUG_OUTPUT
        std::cout << "STATE TRANSITION: Medium::State1->Medium::State2" << std::endl;
        #endif
        
          // going into regular state
          MEDIUM_OBJ__STATE2_OBJ->initialize();
          // make sure nothing else handles this event
          handled = true;
          }
        break;
      default:
        break;
      }
    }
    // can't buble up, we are a root state.
    return handled;
  }
  /* * *  Definitions for Medium::State1::Child2 : /o/r/6  * * */
  // Timer period
  const double Medium::State1::Child2::timerPeriod = 0;
  
  void Medium::State1::Child2::initialize ( void ) {
    // External Transition : Action for: /o/r/6/a
    #ifdef DEBUG_OUTPUT
    std::cout << "TRANSITION::ACTION for /o/r/6/a" << std::endl;
    #endif
    
    //::::/o/r/6/a::::Action::::
    
    // State : entry for: /o/r/6/w
    MEDIUM_OBJ__STATE1_OBJ__CHILD2_OBJ__GRAND_OBJ->entry();
    
    // initialize our new active state
    MEDIUM_OBJ__STATE1_OBJ__CHILD2_OBJ__GRAND_OBJ->initialize();
  }
  
  void Medium::State1::Child2::entry ( void ) {
    #ifdef DEBUG_OUTPUT
    std::cout << "ENTRY::Medium::State1::Child2::/o/r/6" << std::endl;
    #endif
    // Entry action for this state
    //::::/o/r/6::::Entry::::
    
  }
  
  void Medium::State1::Child2::exit ( void ) {
    #ifdef DEBUG_OUTPUT
    std::cout << "EXIT::Medium::State1::Child2::/o/r/6" << std::endl;
    #endif
    // Call the Exit Action for this state
    //::::/o/r/6::::Exit::::
    
  }
  
  void Medium::State1::Child2::tick ( void ) {
    #ifdef DEBUG_OUTPUT
    std::cout << "TICK::Medium::State1::Child2::/o/r/6" << std::endl;
    #endif
    // Call the Tick Action for this state
    //::::/o/r/6::::Tick::::
    
    if ( _activeState != nullptr && _activeState != this )
      _activeState->tick();
  }
  
  double Medium::State1::Child2::getTimerPeriod ( void ) {
    return timerPeriod;
  }
  
  bool Medium::State1::Child2::handleEvent ( StateMachine::Event* event ) {
    bool handled = false;
  
    // take care of all event types that this branch will not handle -
    // for more consistent run-time performnace
    switch ( event->type() ) {
    case Event::Type::EVENT3:
      handled = true;
      break;
    case Event::Type::EVENT4:
      handled = true;
      break;
    default:
      break;
    }
  
    if (handled) {
      // we didn't actually handle the event, but return anyway
      return false;
    }
  
    // handle internal transitions first
    switch ( event->type() ) {
    default:
      break;
    }
    if (!handled) {
      // handle external transitions here
      switch ( event->type() ) {
      case Event::Type::EVENT2:
        if ( false ) { }  // makes generation easier :)
        else if ( true ) {
          #ifdef DEBUG_OUTPUT
          std::cout << "NO GUARD on EXTERNAL TRANSITION:/o/r/0" << std::endl;
          #endif
          // Transitioning states!
          // Call all from prev state down exits
        MEDIUM_OBJ__STATE1_OBJ__CHILD2_OBJ->exitChildren();
        // State : exit for: /o/r/6
        MEDIUM_OBJ__STATE1_OBJ__CHILD2_OBJ->exit();
        // External Transition : Action for: /o/r/0
        #ifdef DEBUG_OUTPUT
        std::cout << "TRANSITION::ACTION for /o/r/0" << std::endl;
        #endif
        
        //::::/o/r/0::::Action::::
        
        // State : entry for: /o/r/P
        MEDIUM_OBJ__STATE1_OBJ__CHILD3_OBJ->entry();
        #ifdef DEBUG_OUTPUT
        std::cout << "STATE TRANSITION: Medium::State1::Child2->Medium::State1::Child3" << std::endl;
        #endif
        
          // going into regular state
          MEDIUM_OBJ__STATE1_OBJ__CHILD3_OBJ->initialize();
          // make sure nothing else handles this event
          handled = true;
          }
        break;
      default:
        break;
      }
    }
    if (!handled) {
      // now check parent states
      handled = _parentState->handleEvent( event );
    }
    return handled;
  }
  /* * *  Definitions for Medium::State1::Child2::Grand2 : /o/r/6/7  * * */
  // Timer period
  const double Medium::State1::Child2::Grand2::timerPeriod = 0.1;
  
  void Medium::State1::Child2::Grand2::initialize ( void ) {
    // if we're a leaf state, make sure we're active
    makeActive();
  }
  
  void Medium::State1::Child2::Grand2::entry ( void ) {
    #ifdef DEBUG_OUTPUT
    std::cout << "ENTRY::Medium::State1::Child2::Grand2::/o/r/6/7" << std::endl;
    #endif
    // Entry action for this state
    //::::/o/r/6/7::::Entry::::
    
  }
  
  void Medium::State1::Child2::Grand2::exit ( void ) {
    #ifdef DEBUG_OUTPUT
    std::cout << "EXIT::Medium::State1::Child2::Grand2::/o/r/6/7" << std::endl;
    #endif
    // Call the Exit Action for this state
    //::::/o/r/6/7::::Exit::::
    
  }
  
  void Medium::State1::Child2::Grand2::tick ( void ) {
    #ifdef DEBUG_OUTPUT
    std::cout << "TICK::Medium::State1::Child2::Grand2::/o/r/6/7" << std::endl;
    #endif
    // Call the Tick Action for this state
    //::::/o/r/6/7::::Tick::::
    
    if ( _activeState != nullptr && _activeState != this )
      _activeState->tick();
  }
  
  double Medium::State1::Child2::Grand2::getTimerPeriod ( void ) {
    return timerPeriod;
  }
  
  bool Medium::State1::Child2::Grand2::handleEvent ( StateMachine::Event* event ) {
    bool handled = false;
  
    // take care of all event types that this branch will not handle -
    // for more consistent run-time performnace
    switch ( event->type() ) {
    case Event::Type::EVENT4:
      handled = true;
      break;
    default:
      break;
    }
  
    if (handled) {
      // we didn't actually handle the event, but return anyway
      return false;
    }
  
    // handle internal transitions first
    switch ( event->type() ) {
    default:
      break;
    }
    if (!handled) {
      // handle external transitions here
      switch ( event->type() ) {
      case Event::Type::EVENT3:
        if ( false ) { }  // makes generation easier :)
        else if ( true ) {
          #ifdef DEBUG_OUTPUT
          std::cout << "NO GUARD on EXTERNAL TRANSITION:/o/r/6/B" << std::endl;
          #endif
          // Transitioning states!
          // Call all from prev state down exits
        MEDIUM_OBJ__STATE1_OBJ__CHILD2_OBJ__GRAND2_OBJ->exitChildren();
        // State : exit for: /o/r/6/7
        MEDIUM_OBJ__STATE1_OBJ__CHILD2_OBJ__GRAND2_OBJ->exit();
        // External Transition : Action for: /o/r/6/B
        #ifdef DEBUG_OUTPUT
        std::cout << "TRANSITION::ACTION for /o/r/6/B" << std::endl;
        #endif
        
        //::::/o/r/6/B::::Action::::
        
        // State : entry for: /o/r/6/w
        MEDIUM_OBJ__STATE1_OBJ__CHILD2_OBJ__GRAND_OBJ->entry();
        #ifdef DEBUG_OUTPUT
        std::cout << "STATE TRANSITION: Medium::State1::Child2::Grand2->Medium::State1::Child2::Grand" << std::endl;
        #endif
        
          // going into regular state
          MEDIUM_OBJ__STATE1_OBJ__CHILD2_OBJ__GRAND_OBJ->initialize();
          // make sure nothing else handles this event
          handled = true;
          }
        break;
      default:
        break;
      }
    }
    if (!handled) {
      // now check parent states
      handled = _parentState->handleEvent( event );
    }
    return handled;
  }
  /* * *  Definitions for Medium::State1::Child2::Grand : /o/r/6/w  * * */
  // Timer period
  const double Medium::State1::Child2::Grand::timerPeriod = 0.1;
  
  void Medium::State1::Child2::Grand::initialize ( void ) {
    // if we're a leaf state, make sure we're active
    makeActive();
  }
  
  void Medium::State1::Child2::Grand::entry ( void ) {
    #ifdef DEBUG_OUTPUT
    std::cout << "ENTRY::Medium::State1::Child2::Grand::/o/r/6/w" << std::endl;
    #endif
    // Entry action for this state
    //::::/o/r/6/w::::Entry::::
    
  }
  
  void Medium::State1::Child2::Grand::exit ( void ) {
    #ifdef DEBUG_OUTPUT
    std::cout << "EXIT::Medium::State1::Child2::Grand::/o/r/6/w" << std::endl;
    #endif
    // Call the Exit Action for this state
    //::::/o/r/6/w::::Exit::::
    
  }
  
  void Medium::State1::Child2::Grand::tick ( void ) {
    #ifdef DEBUG_OUTPUT
    std::cout << "TICK::Medium::State1::Child2::Grand::/o/r/6/w" << std::endl;
    #endif
    // Call the Tick Action for this state
    //::::/o/r/6/w::::Tick::::
    
    if ( _activeState != nullptr && _activeState != this )
      _activeState->tick();
  }
  
  double Medium::State1::Child2::Grand::getTimerPeriod ( void ) {
    return timerPeriod;
  }
  
  bool Medium::State1::Child2::Grand::handleEvent ( StateMachine::Event* event ) {
    bool handled = false;
  
    // take care of all event types that this branch will not handle -
    // for more consistent run-time performnace
    switch ( event->type() ) {
    case Event::Type::EVENT4:
      handled = true;
      break;
    default:
      break;
    }
  
    if (handled) {
      // we didn't actually handle the event, but return anyway
      return false;
    }
  
    // handle internal transitions first
    switch ( event->type() ) {
    default:
      break;
    }
    if (!handled) {
      // handle external transitions here
      switch ( event->type() ) {
      case Event::Type::EVENT3:
        if ( false ) { }  // makes generation easier :)
        else if ( true ) {
          #ifdef DEBUG_OUTPUT
          std::cout << "NO GUARD on EXTERNAL TRANSITION:/o/r/6/y" << std::endl;
          #endif
          // Transitioning states!
          // Call all from prev state down exits
        MEDIUM_OBJ__STATE1_OBJ__CHILD2_OBJ__GRAND_OBJ->exitChildren();
        // State : exit for: /o/r/6/w
        MEDIUM_OBJ__STATE1_OBJ__CHILD2_OBJ__GRAND_OBJ->exit();
        // External Transition : Action for: /o/r/6/y
        #ifdef DEBUG_OUTPUT
        std::cout << "TRANSITION::ACTION for /o/r/6/y" << std::endl;
        #endif
        
        //::::/o/r/6/y::::Action::::
        
        // State : entry for: /o/r/6/7
        MEDIUM_OBJ__STATE1_OBJ__CHILD2_OBJ__GRAND2_OBJ->entry();
        #ifdef DEBUG_OUTPUT
        std::cout << "STATE TRANSITION: Medium::State1::Child2::Grand->Medium::State1::Child2::Grand2" << std::endl;
        #endif
        
          // going into regular state
          MEDIUM_OBJ__STATE1_OBJ__CHILD2_OBJ__GRAND2_OBJ->initialize();
          // make sure nothing else handles this event
          handled = true;
          }
        break;
      default:
        break;
      }
    }
    if (!handled) {
      // now check parent states
      handled = _parentState->handleEvent( event );
    }
    return handled;
  }
  /* * *  Definitions for Medium::State1::Child3 : /o/r/P  * * */
  // Timer period
  const double Medium::State1::Child3::timerPeriod = 0.1;
  
  void Medium::State1::Child3::initialize ( void ) {
    // if we're a leaf state, make sure we're active
    makeActive();
  }
  
  void Medium::State1::Child3::entry ( void ) {
    #ifdef DEBUG_OUTPUT
    std::cout << "ENTRY::Medium::State1::Child3::/o/r/P" << std::endl;
    #endif
    // Entry action for this state
    //::::/o/r/P::::Entry::::
    
  }
  
  void Medium::State1::Child3::exit ( void ) {
    #ifdef DEBUG_OUTPUT
    std::cout << "EXIT::Medium::State1::Child3::/o/r/P" << std::endl;
    #endif
    // Call the Exit Action for this state
    //::::/o/r/P::::Exit::::
    
  }
  
  void Medium::State1::Child3::tick ( void ) {
    #ifdef DEBUG_OUTPUT
    std::cout << "TICK::Medium::State1::Child3::/o/r/P" << std::endl;
    #endif
    // Call the Tick Action for this state
    //::::/o/r/P::::Tick::::
    
    if ( _activeState != nullptr && _activeState != this )
      _activeState->tick();
  }
  
  double Medium::State1::Child3::getTimerPeriod ( void ) {
    return timerPeriod;
  }
  
  bool Medium::State1::Child3::handleEvent ( StateMachine::Event* event ) {
    bool handled = false;
  
    // take care of all event types that this branch will not handle -
    // for more consistent run-time performnace
    switch ( event->type() ) {
    case Event::Type::EVENT2:
      handled = true;
      break;
    case Event::Type::EVENT4:
      handled = true;
      break;
    default:
      break;
    }
  
    if (handled) {
      // we didn't actually handle the event, but return anyway
      return false;
    }
  
    // handle internal transitions first
    switch ( event->type() ) {
    default:
      break;
    }
    if (!handled) {
      // handle external transitions here
      switch ( event->type() ) {
      case Event::Type::EVENT3:
        if ( false ) { }  // makes generation easier :)
        else if ( true ) {
          #ifdef DEBUG_OUTPUT
          std::cout << "NO GUARD on EXTERNAL TRANSITION:/o/r/4" << std::endl;
          #endif
          // Going into a choice pseudo-state, let it handle its
          // guards and perform the state transition
          if (false) { } // makes geneeration easier :)
          //::::/o/r/y::::Guard::::
          else if ( cycle ) {
            #ifdef DEBUG_OUTPUT
            std::cout << "GUARD [ cycle ] for EXTERNAL TRANSITION:/o/r/y evaluated to TRUE" << std::endl;
            #endif
            // Transitioning states!
            // Call all from prev state down exits
          MEDIUM_OBJ__STATE1_OBJ__CHILD3_OBJ->exitChildren();
          // State : exit for: /o/r/P
          MEDIUM_OBJ__STATE1_OBJ__CHILD3_OBJ->exit();
          // External Transition : Action for: /o/r/4
          #ifdef DEBUG_OUTPUT
          std::cout << "TRANSITION::ACTION for /o/r/4" << std::endl;
          #endif
          
          //::::/o/r/4::::Action::::
          
          // External Transition : Action for: /o/r/y
          #ifdef DEBUG_OUTPUT
          std::cout << "TRANSITION::ACTION for /o/r/y" << std::endl;
          #endif
          
          //::::/o/r/y::::Action::::
          
          // State : entry for: /o/r/L
          MEDIUM_OBJ__STATE1_OBJ__CHILD1_OBJ->entry();
          #ifdef DEBUG_OUTPUT
          std::cout << "STATE TRANSITION: Medium::State1::Child3->Medium::State1::Child1" << std::endl;
          #endif
          
            // going into regular state
            MEDIUM_OBJ__STATE1_OBJ__CHILD1_OBJ->initialize();
            // make sure nothing else handles this event
            handled = true;
            }
          else if ( true ) {
            #ifdef DEBUG_OUTPUT
            std::cout << "NO GUARD on EXTERNAL TRANSITION:/o/r/Z" << std::endl;
            #endif
            // Going into an end pseudo-state that is not the root end state,
            // follow its parent end transition
            if (false) { }
            else if ( true ) {
              #ifdef DEBUG_OUTPUT
              std::cout << "NO GUARD on EXTERNAL TRANSITION:/o/T" << std::endl;
              #endif
              // Transitioning states!
              // Call all from prev state down exits
            MEDIUM_OBJ__STATE1_OBJ__CHILD3_OBJ->exitChildren();
            // State : exit for: /o/r/P
            MEDIUM_OBJ__STATE1_OBJ__CHILD3_OBJ->exit();
            // State : exit for: /o/r
            MEDIUM_OBJ__STATE1_OBJ->exit();
            // External Transition : Action for: /o/r/4
            #ifdef DEBUG_OUTPUT
            std::cout << "TRANSITION::ACTION for /o/r/4" << std::endl;
            #endif
            
            //::::/o/r/4::::Action::::
            
            // External Transition : Action for: /o/r/Z
            #ifdef DEBUG_OUTPUT
            std::cout << "TRANSITION::ACTION for /o/r/Z" << std::endl;
            #endif
            
            //::::/o/r/Z::::Action::::
            
            // External Transition : Action for: /o/T
            #ifdef DEBUG_OUTPUT
            std::cout << "TRANSITION::ACTION for /o/T" << std::endl;
            #endif
            
            //::::/o/T::::Action::::
            
            #ifdef DEBUG_OUTPUT
            std::cout << "STATE TRANSITION: Medium::State1::Child3->Medium::End_State" << std::endl;
            #endif
            
              // going into end pseudo-state THIS SHOULD BE TOP LEVEL END STATE
              MEDIUM_OBJ__END_STATE_OBJ->makeActive();
              // make sure nothing else handles this event
              handled = true;
              }
          }
        }
        break;
      default:
        break;
      }
    }
    if (!handled) {
      // now check parent states
      handled = _parentState->handleEvent( event );
    }
    return handled;
  }
  /* * *  Definitions for Medium::State1::Child1 : /o/r/L  * * */
  // Timer period
  const double Medium::State1::Child1::timerPeriod = 0.1;
  
  void Medium::State1::Child1::initialize ( void ) {
    // if we're a leaf state, make sure we're active
    makeActive();
  }
  
  void Medium::State1::Child1::entry ( void ) {
    #ifdef DEBUG_OUTPUT
    std::cout << "ENTRY::Medium::State1::Child1::/o/r/L" << std::endl;
    #endif
    // Entry action for this state
    //::::/o/r/L::::Entry::::
    
  }
  
  void Medium::State1::Child1::exit ( void ) {
    #ifdef DEBUG_OUTPUT
    std::cout << "EXIT::Medium::State1::Child1::/o/r/L" << std::endl;
    #endif
    // Call the Exit Action for this state
    //::::/o/r/L::::Exit::::
    
  }
  
  void Medium::State1::Child1::tick ( void ) {
    #ifdef DEBUG_OUTPUT
    std::cout << "TICK::Medium::State1::Child1::/o/r/L" << std::endl;
    #endif
    // Call the Tick Action for this state
    //::::/o/r/L::::Tick::::
    
    if ( _activeState != nullptr && _activeState != this )
      _activeState->tick();
  }
  
  double Medium::State1::Child1::getTimerPeriod ( void ) {
    return timerPeriod;
  }
  
  bool Medium::State1::Child1::handleEvent ( StateMachine::Event* event ) {
    bool handled = false;
  
    // take care of all event types that this branch will not handle -
    // for more consistent run-time performnace
    switch ( event->type() ) {
    case Event::Type::EVENT2:
      handled = true;
      break;
    case Event::Type::EVENT3:
      handled = true;
      break;
    case Event::Type::EVENT4:
      handled = true;
      break;
    default:
      break;
    }
  
    if (handled) {
      // we didn't actually handle the event, but return anyway
      return false;
    }
  
    // handle internal transitions first
    switch ( event->type() ) {
    default:
      break;
    }
    if (!handled) {
      // handle external transitions here
      switch ( event->type() ) {
      case Event::Type::EVENT1:
        if ( false ) { }  // makes generation easier :)
        else if ( true ) {
          #ifdef DEBUG_OUTPUT
          std::cout << "NO GUARD on EXTERNAL TRANSITION:/o/r/G" << std::endl;
          #endif
          // Transitioning states!
          // Call all from prev state down exits
        MEDIUM_OBJ__STATE1_OBJ__CHILD1_OBJ->exitChildren();
        // State : exit for: /o/r/L
        MEDIUM_OBJ__STATE1_OBJ__CHILD1_OBJ->exit();
        // External Transition : Action for: /o/r/G
        #ifdef DEBUG_OUTPUT
        std::cout << "TRANSITION::ACTION for /o/r/G" << std::endl;
        #endif
        
        //::::/o/r/G::::Action::::
        
        // State : entry for: /o/r/6
        MEDIUM_OBJ__STATE1_OBJ__CHILD2_OBJ->entry();
        #ifdef DEBUG_OUTPUT
        std::cout << "STATE TRANSITION: Medium::State1::Child1->Medium::State1::Child2" << std::endl;
        #endif
        
          // going into regular state
          MEDIUM_OBJ__STATE1_OBJ__CHILD2_OBJ->initialize();
          // make sure nothing else handles this event
          handled = true;
          }
        break;
      default:
        break;
      }
    }
    if (!handled) {
      // now check parent states
      handled = _parentState->handleEvent( event );
    }
    return handled;
  }
};

// Root of the HFSM
StateMachine::Medium *const Medium_root = &StateMachine::MEDIUM_OBJ_stateObj;
// Event Factory
StateMachine::EventFactory EVENT_FACTORY;
StateMachine::EventFactory *const eventFactory = &EVENT_FACTORY;

